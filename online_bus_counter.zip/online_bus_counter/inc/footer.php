    <div class="row footer-panel mgtop70">
    	<div class="container">
        	<div class="col-lg-3">
            	<h3 class=" text-center">ABOUT</h3>
                <ul class="list-group text-primary">
                    <li class="list-group-item">Cras justo odio</li>
                    <li class="list-group-item">Dapibus ac facilisis in</li>
                    <li class="list-group-item">Morbi leo risus</li>
                    <li class="list-group-item">Porta ac consectetur ac</li>
                    <li class="list-group-item">Vestibulum at eros</li>
                </ul>
            </div>
        	<div class="col-lg-3">
            	<h3 class=" text-center">Help</h3>
                <ul class="list-group text-primary">
                    <li class="list-group-item">Cras justo odio</li>
                    <li class="list-group-item">Dapibus ac facilisis in</li>
                    <li class="list-group-item">Morbi leo risus</li>
                    <li class="list-group-item">Porta ac consectetur ac</li>
                    <li class="list-group-item">Vestibulum at eros</li>
                </ul>
            </div>
        	<div class="col-lg-3">
            	<h3 class=" text-center">Services</h3>
                <ul class="list-group text-primary">
                    <li class="list-group-item">Cras justo odio</li>
                    <li class="list-group-item">Dapibus ac facilisis in</li>
                    <li class="list-group-item">Morbi leo risus</li>
                    <li class="list-group-item">Porta ac consectetur ac</li>
                    <li class="list-group-item">Vestibulum at eros</li>
                </ul>
            </div>
        	<div class="col-lg-3">
            	<h3 class=" text-center">Miscellaneous</h3>
                <ul class="list-group text-primary">
                    <li class="list-group-item">Cras justo odio</li>
                    <li class="list-group-item">Dapibus ac facilisis in</li>
                    <li class="list-group-item">Morbi leo risus</li>
                    <li class="list-group-item">Porta ac consectetur ac</li>
                    <li class="list-group-item">Vestibulum at eros</li>
                </ul>
            </div>
            <div class="col-lg-12">
 	            <p class="pull-left">COPYRIGHT &copy; 2015 ONLINE BUS COUNTER</p>
            	<p class="pull-right">
                	<span class="fa fa-2x fa-facebook-square"></span>
                	<span class="fa  fa-2x fa-twitter-square"></span>
                	<span class="fa  fa-2x fa-linkedin-square"></span>
                	<span class="fa  fa-2x fa-google-plus-square"></span>
                	<span class="fa  fa-2x fa-dribbble"></span>
                	<span class="fa  fa-2x fa-pinterest-square"></span>
                </p>
            </div>

        </div>
    </div>
