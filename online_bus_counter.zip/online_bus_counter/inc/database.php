<?php
include("functions.php");

function database_connection()
{
    if(!is_session_started())
    {
        start_session();
    }
    $_SESSION['database_connection'] = mysqli_connect("localhost","root","","obc");
}


function end_database_connection()
{
    if(isset($_SESSION['database_connection']))
	{
        mysqli_close($_SESSION['database_connection']);
    }
}

function authentication($username,$password)
{       
            $query = fetch("SELECT * FROM users WHERE email = '{$username}' AND activate=1  LIMIT 1");
            $get_email = $query[0]['email'];
            $get_password = $query[0]['password'];
            $get_id = $query[0]['id'];
        if( md5($password) == $get_password )
        {   $_SESSION['password']=$pasword; 
            $_SESSION['username'] = $username;
            $_SESSION['id'] = $get_id;
            $_SESSION['welcome'] = 1;
            redirect_to("dashboard.php");  
        }
        else 
        {
            $_SESSION['invalid_message'] = 1;
            redirect_to("signin.php");
        }    
}


function signup($email,$password,$name,$contact)
{
        $query = "INSERT INTO users(email,password,name,mobile,created_at)";
        $query .= "VALUES('{$email}','".md5($password)."','{$name}','{$contact}',now())";
        if (execute($query))
        {

            $subject = 'the subject';
            $message = "Please Click The Link Below And Activate Your Account<br/> <a href='http://onlinebuscounter.com/activate.php?id=".$email."'>Verify Account</a>";
            $headers = 'From: donotreply@onlinebuscounter.com' . "\r\n" .
    'Reply-To: onlinebuscounter@gmail.com' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();

	     mail($email, $subject, $message, $headers);
            $_SESSION['token'] = 1;
            redirect_to("index.php");
        }
        else
        {
            $_SESSION['error_user'] = 1;
            redirect_to("register.php");
        }
}
function booking($guest_name,$guest_phone,$guest_email,$fare,$total_seats,$seat_no,$route,$date_of_journey,$seat_no1,$bus_id,$from_bus_time)
{
        $query = "INSERT INTO order_table(name,mobile,email,fare,no_of_seat,other_seat_no,route_id,date_of_journey,window_seat_no,bus_id,from_bus_time)";
        $query .= "VALUES('{$guest_name}','{$guest_phone}','{$guest_email}','{$fare}','{$total_seats}','{$seat_no}','{$route}','{$date_of_journey}','{$seat_no1}','{$bus_id}','{$from_bus_time}')";
      	    if (execute($query))
        { ?>
        <script type="text/javascript">
            //window.location = "print_ticket.php?print=1";
        </script>
        <?php 
        }
        else
        { 
            $_SESSION['error_user'] = 1;
        ?>
           
        <script type="text/javascript">
           //window.location = "print_ticket.php";
        </script>
        <?php 
        }
}

function fetch($query)
{
    $result1 = array();
    $row = execute($query);
    while($result = mysqli_fetch_array($row,MYSQLI_ASSOC))
    {
       $return[] = $result;
    }
    
		if(!empty($return))
			{
				
				return $return;
			}	



}

function execute($query)
{
   return mysqli_query($_SESSION['database_connection'],$query);
}
?>