
<nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href=""></a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="index.php">Home</a></li>
            <li><a href="cancel_ticket.php">Cancel Ticket</a></li>
          </ul>
            <?php 
                if(isset($_SESSION['username']))
                { ?>
          <ul class="nav navbar-nav pull-right">       
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?= $_SESSION['username'] ?> <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="#contact"   data-toggle="modal">Change Password</a></li>
                <li><a href="myticket.php">My Tickets</a></li>
                <li role="separator" class="divider"></li>
                <li class="dropdown-header">Get Logout</li>
                <li><a href="logout.php">Logout</a></li>
              </ul>
            </li> 
          </ul>
            <?php }
                else
                {
            ?>
          <ul class="nav navbar-nav pull-right">
            <li><a href="signin.php">Sign In</a></li>
            <li><a href="signup.php">Sign Up</a></li>
          </ul>
          <?php } ?>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
    
    <div class="row thumbnail  jumbotron" >
    	<br /><br/>
        <div class="container">
            <p class="pull-left fontsize"><a href="index.php"><span class="glyphicon glyphicon-road"></span> Online Bus Counter</a></p>
            <span class="pull-right">Need Help? Call Toll Number <span class="glyphicon glyphicon-phone"></span> 1860-300-10101</span>
        </div>
    </div>
 
  <?php 
                if(isset($_SESSION['username']))
                { ?>
                          <div class="modal fade" id="contact" role="dialog" >
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                        <h4>Change password</h4>
                                        </div>
                                   <form action="inc/navigation.php?message=1" method="post">
                                      <h5 style="margin-left:60px; ">Your current Password</h5>
                                      <input type="password"  placeholder="old password" name="old" style=" margin-left:60px;;width:400px; height:50px;" />
                                      <h5 style="margin-left:60px; ">Your new password</h5>
                                      <input type="password"  placeholder="new password" name="new" style="margin-left:60px;width:400px; height:50px;" />
                                      <h5 style="margin-left:60px; ">Re-enter password</h5>
                                      <input type="password"  placeholder="re-enter password" name="new1" style="margin-left:60px;width:400px; height:50px;" /><br />
                                      <button class="btn btn-info" style="margin-top:20px;margin-bottom:20px;margin-left:170px;" type="submit">Change the password</button>
                                 </form>
                                       </div>
                                </div>
                           </div>
                  
             <?php
			      }?>
