<?php 
    if(isset($_SESSION['token']))
    { ?>
        <div class="alert alert-info token container mgtop10" role="alert">
        <strong>Account Verification</strong> Go To your email and click on the verify link.
        </div>
    <script>
        $(".token").fadeOut(16000);
    </script>
   <?php
    unset($_SESSION['token']);
    }
?>
<?php 
    if(isset($_SESSION['activate']))
    { ?>
        <div class="alert alert-success activate container mgtop10" role="alert">
        <strong>Account Successfully Activated</strong> 
        </div>
    <script>
        $(".activate").fadeOut(16000);
    </script>
   <?php
    unset($_SESSION['activate']);
    }
?>
<?php 
    if(isset($_SESSION['confirm']))
    { ?>
        <div class="alert alert-info token container mgtop10" role="alert">
        <strong>Confirmation to delete the ticket</strong> Go To your email and click on the link to cancel the ticket.
        </div>
    <script>
        $(".token").fadeOut(16000);
    </script>
   <?php
    unset($_SESSION['confirm']);
    }
?>