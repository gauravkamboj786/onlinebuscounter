<?php
	include("inc/database.php");
	start_session();		
	database_connection();
      
 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Bus Counter</title>
<?php include("inc/scripts.php"); ?>
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
<script src="//code.jquery.com/jquery-1.10.2.js"></script>
<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
<link rel="stylesheet" href="/resources/demos/style.css">
<script type="text/javascript">

</script>
</head>
<body style="background:#FFFFFF;">
<?php include("inc/navigation.php"); ?>
        <?php include("inc/messages.php"); ?>
<?php
if(isset($_GET['detail']))
{  
	if(!isset($_SESSION['username']))
		  {	
?>			<center><h3>Please login to get  discount coupens</h3></center>
               <div class="row" style="margin-top:25px;">
     			<div class="container col-xs-offset-4 col-lg-4 col-xs-offset-4" style="background:rgba(0,0,0,0.6); border-radius:20px; margin-top:-10px; padding-bottom: 30px;">				                	<h3 style="color:white;">Please provide some of your information</h3>
                	  <form action="coupen.php?invoice=1" method="post">	
                        <input type="text" class="form-control"  placeholder="Enter Your Full Name" name="guest_name" required autofocus /><br />
                        <input type="text" class="form-control" placeholder="Phone number" name="guest_phone" required autofocus /><br />
                        <input type="text" class="form-control" placeholder="Email" name="guest_email" required autofocus/><br />
                        <input type="hidden" name="agency_name" value="<?php echo $_POST['agency_name'] ?>"/>
                        <input type="hidden" name="bus_name" value="<?php echo $_POST['bus_name'] ?>"/>
                        <input type="hidden" name="bus_number" value="<?php echo $_POST['bus_number'] ?>"/>
                        <input type="hidden" name="from_bus_time" value="<?php echo $_POST['from_bus_time'] ?>"/>
                        <input type="hidden" name="bus_to_time" value="<?php echo $_POST['bus_to_time'] ?>"/>
                        <input type="hidden" name="seat_no" value="<?php echo $_POST['seats_selected'] ?>"/>
                        <input type="hidden" name="seat_no1" value="<?php echo $_POST['seats_selected1'] ?>"/>
                        <input type="hidden" value="<?php echo $_POST['bus_id'] ?>" name="bus_id" />
                        <input type="hidden" name="date_of_journey" value="<?php echo $_POST['date_of_journey'] ?>"/>
                  		<?php $total_seats=$_POST['number_seats']+$_POST['number_seats1'];  ?>
                  		<label class="text-center" style="color:white;">Number of  seats you selected</label>			
                        <input type="text" class="form-control" value="<?php echo $total_seats ?>" readonly="readonly"  name="total_seats"  required autofocus/><br />
                  		 <?php $price=$_POST['ticket']*$total_seats;?>
                        <label class="text-center" style="color:white;">fare of <?php echo $total_seats ?>seats</label>
                        <input type="text" class="form-control" value="<?php echo $price ?>" readonly="readonly"  name="fare"  required autofocus/><br />  
                        <input type="hidden" value="<?php echo $_POST['route'] ?>" name="route" /> 
                        <button class="btn btn-info form-control center-block mgtop10" type="submit">Book your ticket</button>
                      </form>  
                        </div>
                        </div>
                     </div>
                 </div>      
<?php   }
		if(isset($_SESSION['username']))	
			{ 
			
		 foreach(fetch("select * from `users` where email='".$_SESSION['username']."'")as $user)
						{	
						$query="select * from coupen";
							if(fetch($query))
							{	
			foreach(fetch($query)as $coupens) 
									{?>
									
								<div class="container">
                                   <div class="col-lg-3">		
                                     <div class="elem" style="height:150px;  margin-top:30px; margin-bottom:20px;">
                                            <center><h2><?php echo $coupens['coupen_name'];?></h2></center>
                                           <center><h1><?php echo $coupens['coupen_discount'];?>%</h1></center>
                                     </div>
                                </div>  
                                       
							<?php	}
							}?>
		
              
           <?php      
								
				
                
?>                <div class="row " style="margin-top:25px;">
<div class="container col-xs-offset-4 col-lg-4 col-xs-offset-4" style="background:rgba(0,0,0,0.6); margin-bottom:20px; border-radius:20px; margin-top:-10px;padding-bottom: 30px;">					<?php  $total_seats=$_POST['number_seats']+$_POST['number_seats1'];  		
							$price=$_POST['ticket']*$total_seats;	?>
                             <center> <h3 style="color:white;">Welcome <?php echo $user['name'] ?></h3></center>
							<form action="coupen.php?discount=1" method="post">
                                    <input type="text" class="form-control" value="<?php echo $user['name'] ?>" name="guest_name" required autofocus /><br />
                                    <input type="text" class="form-control" value="<?php echo $user['mobile'] ?>" name="guest_phone" required autofocus /><br />
                                    <input type="text" class="form-control" value="<?php echo $user['email'] ?>" name="guest_email" required autofocus /><br />   
                           			<input type="text" class="form-control"  placeholder="Enter the coupen name" name="coupen_name"  /><br />
                                   <input type="text" class="form-control" value="<?php echo $total_seats ?>"  readonly="readonly"  name="total_seats"  required autofocus/><br />
                                    <input type="text" class="form-control" value="<?php echo $price ?>" readonly="readonly"   name="ticket"  required autofocus/><br /> 
                                    <input type="hidden" name="agency_name" value="<?php echo $_POST['agency_name'] ?>"/>
                                    <input type="hidden" name="bus_name" value="<?php echo $_POST['bus_name'] ?>"/>
                                    <input type="hidden" name="bus_number" value="<?php echo $_POST['bus_number'] ?>"/>
                                    <input type="hidden" name="from_bus_time" value="<?php echo $_POST['from_bus_time'] ?>"/>
                                    <input type="hidden" name="bus_to_time" value="<?php echo $_POST['bus_to_time'] ?>"/>
                                    <input type="hidden" name="seat_no" value="<?php echo $_POST['seats_selected'] ?>"/>
                                    <input type="hidden" name="seat_no1" value="<?php echo $_POST['seats_selected1'] ?>"/>
                                    <input type="hidden" value="<?php echo $_POST['bus_id'] ?>" name="bus_id" />
                                    <input type="hidden" name="date_of_journey" value="<?php echo $_POST['date_of_journey'] ?>" />
                                    <input type="hidden" value="<?php echo $_POST['route'] ?>" name="route" />
                                    <button class="btn btn-info form-control center-block mgtop10" type="submit">Book your ticket</button>
                            </form>
				<?php       }
			}
					
 }
 ?> </div>
 </div>
 <?php 
 if(isset($_GET['discount']))
 {
 	$query="select *
					from (
						select *   from coupen
						union all
						select * from coupens
						
					) a
					where coupen_name = '".$_POST['coupen_name']."'";
	if(fetch($query))
		{
			foreach(fetch($query) as $coupen)
				{	
					$a=($_POST['ticket']/100);
					$b=($a*$coupen['coupen_discount']);
					$c=$_POST['ticket']-$b;?>
<div class="row " style="margin-top:25px;">
    <div class="container col-xs-offset-4 col-lg-4 col-xs-offset-4" style="background:rgba(0,0,0,0.6); margin-bottom:20px; border-radius:20px; margin-top:-10px;             padding-bottom: 30px;">	
        		<center><h2 style="color:#FFFFFF;">Fare of journey</h2></center> 
 					<form action="coupen.php?invoice=1" method="post"> 
                    	<input type="hidden" name="guest_name" value="<?php echo $_POST['guest_name'] ?>"/>
                          <input type="hidden" name="guest_phone" value="<?php echo $_POST['guest_phone'] ?>"/>
                          <input type="hidden" name="guest_email" value="<?php echo $_POST['guest_email'] ?>"/>
                          <input type="hidden" name="ticket" value="<?php echo $_POST['ticket'] ?>"/>
                          <input type="hidden" name="total_seats" value="<?php echo $_POST['total_seats'] ?>"/>
                          <input type="hidden" name="agency_name" value="<?php echo $_POST['agency_name'] ?>"/>
                          <input type="hidden" name="bus_name" value="<?php echo $_POST['bus_name'] ?>"/>
                          <input type="hidden" name="bus_number" value="<?php echo $_POST['bus_number'] ?>"/>
                          <input type="hidden" name="from_bus_time" value="<?php echo $_POST['from_bus_time'] ?>"/>
                          <input type="hidden" name="bus_to_time" value="<?php echo $_POST['bus_to_time'] ?>"/>
                          <input type="hidden" name="seat_no" value="<?php echo $_POST['seat_no'] ?>"/>
                          <input type="hidden" name="seat_no1" value="<?php echo $_POST['seat_no1'] ?>"/>
                          <input type="hidden" value="<?php echo $_POST['bus_id'] ?>" name="bus_id" />
                          <input type="hidden" value="<?php echo $_POST['route'] ?>" name="route" />
                          <input type="hidden" name="date_of_journey" value="<?php echo $_POST['date_of_journey'] ?>" />
                           <input type="text" class="form-control" value="<?php echo $c ?>" readonly="readonly" name="fare" required autofocus /><br />
                    	<button class="btn btn-info form-control center-block mgtop10" type="submit">Book your ticket</button>	
                    </form>
         	  </div>
       </div>
					<?php
					
				}
		}				
 	else
		{?>
			<p>oops! sorry this coupen does not exist</p>
	<?php }
 }
 ?>

 
 <?php 
 if(isset($_GET['invoice']))
 {?> 
 
 	<div class="container">		
        <p>Online bus counter</p>
        <p>123 abc st</p>
        <p>tel number</p>
        <p>online_bus_counter.com</p>
        <div class="row" style="background:#333333;height:20px;">
        	<p style="color:#FFFFFF; text-align:center">Invoice</p>
        </div>
       <div class="row">
       		<div class="col-lg-4">
            	<h4>Ticket to</h4>
                <p><?php echo  $_POST['guest_name'] ?></p>
                <p><?php echo $_POST['guest_email']?></p>
                <p><?php echo $_POST['guest_phone']?></p>
            </div>
            <div class="col-lg-4">
            	<h4>Bus details</h4>
                <p>bus name : <?php echo $_POST['bus_name'] ?></p>
                <p>bus number : <?php  echo $_POST['bus_number']?></p> 
                <p>Bus time <?php echo $_POST['from_bus_time'] ?></p> 
                <p>Agency name : <?php echo $_POST['agency_name']?></p>          	
            </div>
			<div class="col-lg-4">
            	<p style="text-align:center">Date of journey : <?php echo $_POST['date_of_journey']?></p>
            </div>
       </div> 
     </div>   
     <div class="container" style="background:#000000;height:1px;">
     </div>
    
      <div class="container" style="margin-top:40px;">
     <table border="1" style="width:100%">
     <thead>
     <tr>
         <td style="text-align:center">No of seats</td>
         <td style="text-align:center">seat number</td>
         <td>price</td>
     </tr>
     </thead>
    	 <tbody>
     		<tr>
            	<td style="text-align:center"><?php echo $_POST['total_seats'] ?></td>
                <td style="text-align:center">Window seat number: <?php echo $_POST['seat_no']?><br />other seat number: <?php echo $_POST['seat_no1']?></td>
                <td><?php echo $_POST['fare'] ?></td>
            </tr>
           
        </tbody>
     </table>
     <div class="container">
              <div class="col-lg-8">
              </div>
              <div class="col-lg-4">
				<p style="float:right; margin-right:20px;">sub total : <?php echo $_POST['fare']?> </p>                  
              </div>
          </div>
     
     </div>
     <p style="text-align:center">If you have any question regarding your invoice you can contact the following </p>
     <p style="text-align:center"> phn no ########</p>
     <p style="text-align:center">email id :-----------</p>
     <?php $query="select * from order_table where name='".$_POST['guest_name']."' and mobile='".$_POST['guest_phone']."' and email='".$_POST['guest_email']."' 
	  and no_of_seat='".$_POST['total_seats']."' and other_seat_no='".$_POST['seat_no']."' and window_seat_no='".$_POST['seat_no1']."' 
	 and date_of_journey='".$_POST['date_of_journey']."' and bus_id=".$_POST['bus_id']." and from_bus_time='".$_POST['from_bus_time']."'";
	
	   if(fetch($query))
	   	{
        	
     	}
		else
			{
			booking($_POST['guest_name'],$_POST['guest_phone'],$_POST['guest_email'],$_POST['fare'],$_POST['total_seats'],$_POST['seat_no'],$_POST['route'],
			$_POST['date_of_journey'],$_POST['seat_no1'],$_POST['bus_id'],$_POST['from_bus_time']);
			
            }
     ?>
<?php	
 }
 
 ?>
  
 

</body>
</html>
