<?php
	include("inc/database.php");
	start_session();	
	database_connection();
	if(!isset($_SESSION['admin']))
	{
		redirect_to("index.php");
	}	
	
 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<?php include("inc/scripts.php"); ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Bus Counter</title>
</head>

<body>
	<?php include("inc/navigation.php"); ?>
    <div class="container">
        <?php include("inc/sidebar.php"); ?>
        <div class="row">
       		 <div class="col-lg-12" style="font-size: 14px;">
       				 <div class="panel panel-primary"">
           				 <div class="panel-heading">
                                   <h3 class="panel-title">Delete timming</h3>
            			</div>
           					 <div class="panel-body">
               
              		<div class="col-lg-12">
                        <div class="col-lg-10">
                       	<form class="form-signin mgtop10" action="delete_timming.php?add=1" method="post">
                       		<select class="form-control" name="bus_id" >
                            <option>Select Bus of which you have to delete timming</option>
                       <?php 			 
                          foreach(fetch("SELECT * FROM bus") as $agent)
                            { ?>                    
                            <option value="<?=$agent['id']?>"><?=$agent['name']?>(<?=$agent['bus_number']?>)</option>
                        <?php    
                            }
                        ?>
                        </select>
                        
                        </div>
                         <button class="btn-success" style="width:80px;height:35px;" >Go</button>
                        
                        </form>
                         
                   </div>   
                    </div>
                  </div>
                </div>
                </div>   
     
	 
	 <?php   if(isset($_GET['add']))
	 	{	
				if($_POST['bus_id']==0)
	  				{?>	<script>
                            alert("Enter the bus first of which you have delete the time");
                            window.location="delete_timming.php"
                            </script>
                    <?php }?>
		
	<?php	if($_POST['bus_id']>=1)
	  				{?>
		        
         <form action="delete_timming.php?go=1" method="post">
         <div class="row" style="margin-bottom:80px;">
        <div class="container col-xs-offset-4 col-lg-4 col-xs-offset-4" style="background:rgba(0,0,0,1); border-radius:20px; margin-top:-10px; padding-bottom:30px;">   
                	<div class="col-lg-12thumbnail" style="margin-bottom:15px;margin-top:15px;"> 
                         <h4 style="color:white;">Select route of bus of which You have to edit time</h4> 
                         <select class="form-control" name="route_id" style="margin-bottom:12px;">  
                           <option value="0">Select route</option>             
    
           
                  <?php
						  foreach(fetch("SELECT * FROM routes where bus_id=".$_POST['bus_id']."") as $route)
								{ 			
											  ?>
                               <?php  foreach(fetch("SELECT * FROM cities where city_id=".$route['boarding_point_id']."") as $cityb)
														{ ?>  
											<?php  foreach(fetch("SELECT * FROM cities where city_id=".$route['dropping_point_id']."") as $citya)
							{ ?>   <option value= <?php echo $route['id']  ?>><?php echo $cityb['city_name']?>-<?php echo $citya['city_name']?>                                      </option>
                                                       
													<?php    
														}
                                                   }

													?>
                                             
										                       
								  </div><?php
								}
	               		?>
                    </select>
                    </form>

                <label></label>
                <button class="btn btn-info form-control center-block mgtop20" type="submit">go</button>
              </form>   
      </div>
    </div>    
    </div> 
   <?php 
   }
   }
   ?>  
 <?php  
 if(isset($_GET['go']))       
	{
      if($_POST['route_id']==0)
	  {?>	<script>
      			alert("Enter the route first of which you have add the time");
                window.location="timming.php"
	  		</script>
	<?php }?>
	
	
    <?php if($_POST['route_id']>=0)
	{?>
	  <div class="container">
                	 <div class="panel panel-primary">
                              <div class="panel-heading">
                   		          <h3 class="panel-title">Detail of Time</h3>
                             </div>
                       <div class="panel-body" style="margin-bottom:18px;" >   
                               
                                <div class="col-lg-12 thumbnail" style="margin-bottom:15px;"> 
                                        <div class="col-lg-3"><b>Departure time</b></div>
                                        <div class="col-lg-3"><b>Reaching time</b></div>
                                        <div class="col-lg-3"><b>Day</b></div>
                                        <div class="col-lg-3"><b>Delete</b></div>
                                 </div>  
								
	    						
						 <?php
						  foreach(fetch("SELECT * FROM timming where route_id=".$_POST['route_id']." ") as $agent)
								{ ?>
                                	            
                                    		<div class="col-lg-12 thumbnail" style="margin-bottom:15px;" >
                                            	<div class="col-lg-3"><b><?php echo $agent['from_bus_time'] ?></b></div>
                                                <div class="col-lg-3"><b><?php echo $agent['bus_to_time'] ?></b></div>
                                                <div class="col-lg-3"><b><?php echo $agent['Day'] ?></b></div>
                                                 <div class="col-lg-3"><b> <?php echo "<a href='delete_timming.php?id=".$agent['id']."'><span 				                                                class='glyphicon  glyphicon-remove'style='font-size:30px;'></span></a>";  ?></b></div>
                                            </div> 
                                            
                                                                         
                             <?php }
                                           
        		
				}?>
			</div>
		</div>
	  </div>			 	
				
			<?php }				   ?>                                        
   		
<?php                
 if(isset($_GET['id']))
    {
        $query = "DELETE FROM timming WHERE id ={$_GET['id']} LIMIT 1";
        execute($query);
    ?>
        <script type="text/javascript">
            window.location = "delete_timming.php";
        </script>
        <?php     
    }
?>                             
					    
       
   
	<?php include("inc/footer.php"); ?>
	
</body>
</html>

   
  

<?php end_database_connection(); ?>