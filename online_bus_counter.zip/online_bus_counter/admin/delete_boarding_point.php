<?php
	include("inc/database.php");
	start_session();	
	database_connection();
	if(!isset($_SESSION['admin']))
	{
		redirect_to("index.php");
	}	
	
 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<?php include("inc/scripts.php"); ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Bus Counter</title>
</head>

<body>
	<?php include("inc/navigation.php"); ?>
    <div class="container" >
        <?php include("inc/sidebar.php"); ?>
       <div class="row">
        <div class="col-lg-12" style="font-size: 14px;">
        <div class="panel panel-primary" style="margin-bottom: 50px;">
            <div class="panel-heading">
              <h3 class="panel-title">Show buses</h3>
            </div>
           	 <div class="panel-body">
               
              <div class="col-lg-9">
                       <form class="form-signin mgtop10" action="delete_boarding_point.php?add=1" method="post">
                       <select class="form-control" name="city_id">
                            <option>Select city of which you have to see boarding points</option>
                       <?php 			 
                          foreach(fetch("SELECT * FROM cities") as $agent)
                            { ?>                    
                            <option value="<?=$agent['city_id']?>"><?=$agent['city_name']?>(<?=$agent['city_state']?>)</option>
                        <?php    
                            }
                        ?>
                        </select>
                        
                </div>
                           <div class="col-lg-1"></div>
                           <div class="col-lg-2">
                                 <button class="btn btn-success">search</button>   

                            </div>
                       </div> 
                           
                    </div>
                  </div>
                </div>
                                    
                </div>    
                    </form>
                    
     <?php  if(isset($_GET['add']) && $_GET['add'] == 1)
	 			{	?>	
                	<div class="container">
                	 <div class="panel panel-primary">
                              <div class="panel-heading">
                   		          <h3 class="panel-title">Point name</h3>
                             </div>
                       <div class="panel-body" style="margin-bottom:18px;" >   
                                <div class="col-lg-12 thumbnail" style="margin-bottom:15px;"> 
                                        <div class="col-lg-2"><b>point name</b></div>
                                        <div class="col-lg-2 pull-right" style="margin-right:20px;"><b>delete</b></div>
                                </div>  
	
						 <?php
						 
						  foreach(fetch("SELECT * FROM boarding_point where city_id=".$_POST['city_id']."") as $agent)
								{?>  
                                	            
                                    		<div class="col-lg-12 thumbnail" style="margin-bottom:15px;" > 
                                             
                                            <div class="col-lg-2"><?=$agent['point_name']?></div>
                                           
                                        <div class="pull-right" style="margin-right:150px;">    
										 <?php echo "<a href='delete_boarding_point.php?id=".$agent['id']."'><span class='glyphicon                                                   glyphicon-remove'style='font-size:30px;'></span></a>";  ?>
										</div>		
							  	
								  </div><?php
								}
	               			}
							
							 ?>
                            	
                      </div>
				  </div>
                </div>
                <?php 
   if(isset($_GET['id']))
    {
        $query = "DELETE FROM boarding_point WHERE id = {$_GET['id']} LIMIT 1";
        execute($query);
    ?>
        <script type="text/javascript">
            window.location = "delete_boarding_point.php";
        </script>
        <?php     
    }
?>                                
			
	<?php include("inc/footer.php"); ?>
</body>
</html>
<?php end_database_connection(); ?>