<?php
	include("inc/database.php");
	start_session();	
	database_connection();
	if(!isset($_SESSION['admin']))
	{
		redirect_to("index.php");
	}	
	
 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<?php include("inc/scripts.php"); ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Bus Counter</title>
</head>

<body>
	<?php include("inc/navigation.php"); ?>
    <div class="container" style="margin-bottom: 50px;">
        <?php include("inc/sidebar.php"); ?>
        <div class="col-lg-12" style="font-size: 14px;">
        <div class="panel panel-primary">
            <div class="panel-heading">
              <h3 class="panel-title">Users</h3>
            </div>
            <div class="panel-body" >
                <div class="col-lg-12">
                    <div class="col-lg-12 thumbnail"> 
                        <div class="col-lg-4"><b>Name</b></div>
                        <div class="col-lg-4"><b>mobile</b></div>
                        <div class="col-lg-4"><b>email</b></div>
                        <div class="col-lg-4"><b>fare</b></div>
                         <div class="col-lg-4"><b>no of seat</b></div>
                        <div class="col-lg-4"><b>other seat_no</b></div>
                        <div class="col-lg-4"><b>route</b></div>
                        <div class="col-lg-4"><b>date of journey</b></div>
                         <div class="col-lg-4"><b>window seat number</b></div>
                        <div class="col-lg-4"><b>bus id</b></div>
                        <div class="col-lg-4"><b>From bus time</b></div>
                     </div>
                <?php 
                    foreach(fetch("SELECT * FROM  order_table  LIMIT 10") as $client)
                    { ?>                    
                    <div class="col-lg-12 thumbnail"> 
                        <div class="col-lg-4"><?=$client['name']?></div>
                        <div class="col-lg-4"><?=$client['mobile']?></div>
                        <div class="col-lg-4"><?=$client['email']?></div>
                        <div class="col-lg-4"><?=$client['fare']?></div>
                        <div class="col-lg-4"><?=$client['no_of_seat']?></div>
                        <div class="col-lg-4"><?=$client['other_seat_no']?></div>
                        <div class="col-lg-4">
						<?php 
                         foreach(fetch("select * from routes where id=".$client['route_id']."")as $route)
						 	{
								foreach(fetch("select * from cities where city_id=".$route['boarding_point_id']."")as $city1)
									{?>
                                    		<?= $city1['city_name']?>
							 <?php  }
							}
							 foreach(fetch("select * from routes where id=".$client['route_id']."")as $route)
						 	{
								foreach(fetch("select * from cities where city_id=".$route['dropping_point_id']."")as $city1)
									{?>
                                    		<?= $city1['city_name']?>
							 <?php  }
							}
						 	
                        ?>
                        </div>
                        <div class="col-lg-4"><?=$client['date_of_journey']?></div>
                        <div class="col-lg-4"><?=$client['window_seat_no']?></div>
                        <div class="col-lg-4">
                          <?php
						  		foreach(fetch("select * from bus where id=".$client['bus_id']."")as $bus)
									{			
										echo $bus['name'];
									}
						  ?>
                        </div>
                        <div class="col-lg-4"><?=$client['from_bus_time']?></div>
                    </div>
                    
                <?php    }
                ?>
                </div>    
            </div>
          </div>
            
        </div>
    </div>    
 
   
	<?php include("inc/footer.php"); ?>
	
</body>
</html>
<?php end_database_connection(); ?>