<?php
	include("inc/database.php");
	start_session();	
	database_connection();
	if(!isset($_SESSION['admin']))
	{
		redirect_to("index.php");
	}	
	
 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<?php include("inc/scripts.php"); ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Bus Counter</title>
</head>

<body>
	<?php include("inc/navigation.php"); ?>
    <div class="container" >
        <?php include("inc/sidebar.php"); ?>
       <div class="row">
        <div class="col-lg-12" style="font-size: 14px;">
        <div class="panel panel-primary" style="margin-bottom: 50px;">
            <div class="panel-heading">
              <h3 class="panel-title">Show buses</h3>
            </div>
           	 <div class="panel-body">
               
              <div class="col-lg-9">
                       <form class="form-signin mgtop10" action="bus.php?add=1" method="post">
                       <select class="form-control" name="agency_id">
                            <option>SELECT AGENCY</option>
                       <?php 			 
                          foreach(fetch("SELECT * FROM agency") as $agent)
                            { ?>                    
                            <option value="<?=$agent['id']?>"><?=$agent['name']?></option>
                        <?php    
                            }
                        ?>
                        </select>
                        
                </div>
                           <div class="col-lg-1"></div>
                           <div class="col-lg-2">
                                 <button class="btn btn-success">search</button>   

                            </div>
                       </div> 
                           
                    </div>
                  </div>
                </div>
                                    
                </div>    
                    </form>
                    
     <?php  if(isset($_GET['add']) && $_GET['add'] == 1)
	 			{	?>	
                	<div class="container">
                	 <div class="panel panel-primary">
                              <div class="panel-heading">
                   		          <h3 class="panel-title">Detail of buses</h3>
                             </div>
                       <div class="panel-body" style="margin-bottom:18px;" >   
                                <div class="col-lg-12 thumbnail" style="margin-bottom:15px;"> 
                                        <div class="col-lg-2"><b>Name</b></div>
                                        <div class="col-lg-2"><b>mobile</b></div>
                                        <div class="col-lg-2"><b>Timmings</b></div>
                                        <div class="col-lg-2"><b>Driver name</b></div>
                                        <div class="col-lg-2"><b>Driver detail</b></div>
                                        <div class="col-lg-2"><b>Ticket</b></div>
                                    </div>  
	
						 <?php
						  foreach(fetch("SELECT * FROM bus where agency_id=".$_POST['agency_id']." ") as $agent)
								{?>  
                                	            
                                    		<div class="col-lg-12 thumbnail" style="margin-bottom:15px;" > 
                                             
                                            <div class="col-lg-2"><?=$agent['name']?></div>
                                            <div class="col-lg-2"><?=$agent['bus_number']?></div>
                                            <div class="col-lg-2"><?=$agent['timmings']?></div>
                                            <div class="col-lg-2"><?=$agent['driver_name']?></div>
                                            <div class="col-lg-2"><?=$agent['driver_details']?></div>
                                            <div class="col-lg-2"><?=$agent['ticket']?></div>
										
							  	
								  </div><?php
								}
	               			}
							
							 ?>
                            	
                      </div>
				  </div>
                </div>  
			
	<?php include("inc/footer.php"); ?>
</body>
</html>
<?php end_database_connection(); ?>