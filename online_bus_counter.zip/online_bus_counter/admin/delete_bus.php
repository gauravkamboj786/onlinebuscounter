<?php
	include("inc/database.php");
	start_session();	
	database_connection();
	if(!isset($_SESSION['admin']))
	{
		redirect_to("index.php");
	}	
	
 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<?php include("inc/scripts.php"); ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Bus Counter</title>
</head>

<body>
	<?php include("inc/navigation.php"); ?>
    <div class="container" style="margin-bottom: 50px;">
        <?php include("inc/sidebar.php"); ?>
       <div class="row">
        <div class="col-lg-12" style="font-size: 14px;">
        <div class="panel panel-primary">
            <div class="panel-heading">
              <h3 class="panel-title">Show buses</h3>
            </div>
            <div class="panel-body" >
               
              <div class="col-lg-9">
                       <form class="form-signin mgtop10" action="delete_bus.php?add=1" method="post">
                       <select class="form-control" name="agency_id">
                            <option>SELECT AGENCY</option>
                       <?php 			 
                          foreach(fetch("SELECT * FROM agency") as $agent)
                            { ?>                    
                            <option value="<?=$agent['id']?>"><?=$agent['name']?></option>
                        <?php    
                            }
                        ?>
                        </select>
                        
                </div>
                           <div class="col-lg-1"></div>
                           <div class="col-lg-2">
                                 <button class="btn btn-success">search</button>   

                            </div>
                       </div> 
                           
                    </div>
                  </div>
                </div>
                                    
                </div>    
                    </form>
                    
     <?php  if(isset($_GET['add']) && $_GET['add'] == 1)
	 			{	?>	
                	<div class="container">
                	 <div class="panel panel-primary">
                              <div class="panel-heading">
                   		          <h3 class="panel-title">Detail of buses</h3>
                             </div>
                       <div class="panel-body" > 
                       			 <div class="col-lg-12 thumbnail"> 
                                    <div class="col-lg-12 thumbnail"> 
                                        <div class="col-lg-2"><b>Name</b></div>
                                        <div class="col-lg-2"><b>mobile</b></div>
                                        <div class="col-lg-2"><b>Timmings</b></div>
                                        <div class="col-lg-2"><b>Driver name</b></div>
                                        <div class="col-lg-2"><b>Ticket</b></div>
                                         <div class="col-lg-2"><b>Delete</b></div>
                                    </div>    
                                    <?php	
						
						  foreach(fetch("SELECT * FROM bus where agency_id=".$_POST['agency_id']." ") as $agent)
								{?>  
                                	            
                                   
                                <div class="col-lg-12 thumbnail">
                                            <div class="col-lg-2"><?=$agent['name']?></div>
                                            <div class="col-lg-2"><?=$agent['bus_number']?></div>
                                            <div class="col-lg-2"><?=$agent['timmings']?></div>
                                            <div class="col-lg-2"><?=$agent['driver_name']?></div>
                                            <div class="col-lg-2"><?=$agent['ticket']?></div>
                                            <div class="col-lg-2">
                          					  <?php 
                                    echo "<a href='delete_bus.php?id=".$agent['id']."'><span class='glyphicon glyphicon-remove'
									style='font-size:30px;'></span></a>";
                            ?> 
										</div>	
							  	
								  </div><?php
								}
	               			} ?>	
                      </div>
				  </div>
                </div> 
                
                
<?php 
    if(isset($_GET['id']))
    {
        $query = "DELETE FROM bus WHERE id = {$_GET['id']} LIMIT 1";
        execute($query);
    ?>
        <script type="text/javascript">
            window.location = "delete_bus.php";
        </script>
        <?php     
    }
?>                 
	<?php include("inc/footer.php"); ?>
	
</body>
</html>
<?php end_database_connection(); ?>