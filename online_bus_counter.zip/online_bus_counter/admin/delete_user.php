<?php
	include("inc/database.php");
	start_session();	
	database_connection();
	if(!isset($_SESSION['admin']))
	{
		redirect_to("index.php");
	}	
	
 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<?php include("inc/scripts.php"); ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Bus Counter</title>
</head>

<body>
	<?php include("inc/navigation.php"); ?>
    <div class="container" style="margin-bottom: 50px;">
        <?php include("inc/sidebar.php"); ?>
        <div class="col-lg-12" style="font-size: 14px;">
        <div class="panel panel-primary">
            <div class="panel-heading">
              <h3 class="panel-title">Users</h3>
            </div>
            <div class="panel-body">
                <div class="col-lg-12">
                    <div class="col-lg-12 thumbnail"> 
                        <div class="col-lg-3"><b>Name</b></div>
                        <div class="col-lg-4"><b>Email</b></div>
                        <div class="col-lg-3"><b>Contact</b></div>
                        <div class="col-lg-2"><b>Delete</b></div>
                    </div>
                <?php 
                    foreach(fetch("SELECT * FROM users  LIMIT 10") as $user)
                    { ?>                    
                    <div class="col-lg-12 thumbnail"> 
                        <div class="col-lg-3"><?=$user['name']?></div>
                        <div class="col-lg-4"><?=$user['email']?></div>
                        <div class="col-lg-3"><?=$user['mobile']?></div>
                        <div class="col-lg-2">
                            <?php 
                                    echo "<a href='delete_user.php?id=".$user['id']."'><span class='glyphicon glyphicon-remove' style='font-size:30px;'></span></a>";
                            ?>
                            
                        </div>
                    </div>
                    
                <?php    }
                ?>
                </div>    
            </div>
          </div>
            
        </div>
    </div>    
 
   
	<?php include("inc/footer.php"); ?>
	
</body>
</html>
<?php 
    if(isset($_GET['id']))
    {
        $query = "DELETE FROM users WHERE id = {$_GET['id']} LIMIT 1";
        execute($query);
    ?>
        <script type="text/javascript">
            window.location = "delete_user.php";
        </script>
        <?php     
    }
?>

<?php end_database_connection(); ?>