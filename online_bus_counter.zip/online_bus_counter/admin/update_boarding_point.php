<?php
	include("inc/database.php");
	start_session();	
	database_connection();
	if(!isset($_SESSION['admin']))
	{
		redirect_to("index.php");
	}	
	
 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<?php include("inc/scripts.php"); ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Bus Counter</title>
</head>

<body>
	<?php include("inc/navigation.php"); ?>
    <div class="container" style="margin-bottom: 50px;">
        <?php include("inc/sidebar.php"); ?>
       <div class="row">
        <div class="col-lg-12" style="font-size: 14px;">
        <div class="panel panel-primary">
            <div class="panel-heading">
              <h3 class="panel-title">Show buses</h3>
            </div>
            <div class="panel-body" >
               
              <div class="col-lg-9">
                       <form class="form-signin mgtop10" action="update_boarding_point.php?add=1" method="post">
                       <select class="form-control" name="agency_id">
                            <option>SELECT City</option>
                       <?php 			 
                          foreach(fetch("SELECT * FROM cities") as $agent)
                            { ?>                    
                            <option value="<?=$agent['city_id']?>"><?=$agent['city_name']?> (<?=$agent['city_state']?>)</option>
                        <?php    
                            }
                        ?>
                        </select>
                        
                </div>
                           <div class="col-lg-1"></div>
                           <div class="col-lg-2">
                                 <button class="btn btn-success">search</button>   

                            </div>
                       </div> 
                           
                    </div>
                  </div>
                </div>
                                    
                </div>    
                    </form>
                    
     <?php  if(isset($_GET['add']) && $_GET['add'] == 1)
	 
	 
	 			
	 			{	?>	
                	<div class="container">
                	 <div class="panel panel-primary">
                              <div class="panel-heading">
                   		          <h3 class="panel-title">Detail of buses</h3>
                             </div>
                       <div class="panel-body" > 
                       			 <div class="col-lg-12 thumbnail"> 
                                    <div class="col-lg-12 thumbnail"> 
                                        <div class="col-lg-2"><b>Point name</b></div>
                                        <div class="col-lg-8"></div>
                                        <div class="col-lg-2" style="margin-right:15px;float:right"><b>update</b></div>
                                        
                                    </div>    
                                    <?php	
						
						  foreach(fetch("SELECT * FROM boarding_point where city_id=".$_POST['agency_id']." ") as $agent)
								{?>  
                                	            
                                   
                                <div class="col-lg-12 thumbnail">
                                            <div class="col-lg-2"><?=$agent['point_name']?></div>
                                           <div class="col-lg-8"></div>
                          					 
                                              <?php 
                                    echo "<a href='update_boarding_point.php?id=".$agent['id']."'><span class='glyphicon glyphicon-edit'
									style='font-size:30px;'></span></a>";
                            ?> 
											
                                        
							  	
								  </div><?php
								}
	               			} ?>
                            </div>	
                      </div>
				  </div>
                </div> 
                
                
<?php 
    if(isset($_GET['id']))
   		{  
            foreach(fetch("SELECT * FROM boarding_point WHERE id = ".$_GET['id']."  LIMIT 1") as $user)
            {
                $getname = $user['point_name'];
                
            }
            ?>
        <div class="container col-xs-offset-4 col-lg-4 col-xs-offset-4" style="background:rgba(0,0,0,1); border-radius:20px; margin-top:-10px; 														                  padding-bottom: 40px;margin-bottom: 100px;">       
                <form class="form-signin mgtop10" action="update_boarding_point.php?update=<?=$_GET['id']?>" method="post">
                <h2 style="color:white;">Update</h2>
                <input type="text" id="inputEmail" class="form-control" placeholder="Bus name" name="name" value="<?=$getname?>" 			                 required autofocus><br/>
               
              	
                <label></label>
                <button class="btn btn-info form-control center-block mgtop10" type="submit">Update</button>
              </form>   
      </div>
        <?php 
        
				
    	}
?>  
<?php 
    if(isset($_GET['update']))
    {
        $query = "UPDATE boarding_point SET point_name='".$_POST['name']."'  WHERE id =".$_GET['update']." LIMIT 1 ";
     
	    execute($query);
    ?>
        <script type="text/javascript">
           window.location = "update_boarding_point.php";
        </script>
        <?php     
    }
?>

               
	<?php include("inc/footer.php"); ?>
    
	
</body>
</html>
<?php end_database_connection(); ?>