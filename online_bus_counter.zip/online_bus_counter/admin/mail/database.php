<?php
include("functions.php");

function database_connection()
{
    if(!is_session_started())
    {
        start_session();
    }
    $_SESSION['database_connection'] = mysqli_connect("localhost","root","","obc");
}


function end_database_connection()
{
    if(isset($_SESSION['database_connection'])){
        mysqli_close($_SESSION['database_connection']);
    }
}

function authentication($username,$password)
{       
            $query = fetch("SELECT * FROM admin WHERE email = '{$username}' LIMIT 1");
            $get_email = $query[0]['email'];
            $get_password = $query[0]['password'];
            $get_id = $query[0]['id'];
        if( md5($password) == $get_password )
        {
            $_SESSION['admin'] = $username;
            $_SESSION['id'] = $get_id;
            $_SESSION['welcome'] = 1;
            redirect_to("dashboard.php");  
        }
        else 
        {
            $_SESSION['invalid_message'] = 1;
            redirect_to("index.php");
        }    
}


function signup($email,$password,$name,$contact)
{
        $query = "INSERT INTO users(email,password,name,mobile,created_at)";
        $query .= "VALUES('{$email}','".md5($password)."','{$name}','{$contact}',now())";
        if (execute($query))
        { ?>
        <script type="text/javascript">
            window.location = "user.php";
        </script>
        <?php 
        }
        else
        { 
            $_SESSION['error_user'] = 1;
        ?>
           
        <script type="text/javascript">
            window.location = "user.php";
        </script>
        <?php 
        }
}
function signup_agency($name,$mobile,$admin_id)
{
        $query = "INSERT INTO agency(name,mobile,created_at,admin_id)";
        $query .= "VALUES('{$name}','{$mobile}',now(),'{$admin_id}')";
        if (execute($query))
        { ?>
        <script type="text/javascript">
            window.location = "agency.php";
        </script>
        <?php 
        }
        else
        { 
            $_SESSION['error_user'] = 1;
        ?>
           
        <script type="text/javascript">
            window.location = "add_agency.php";
        </script>
        <?php 
        }
}
function add_bus($name,$bus_number,$agency_id,$Timmings,$window_seat,$other_seat,$driver_name,$driver_details,$ticket)
{
        $query = "INSERT INTO bus(created_at,name,bus_number,agency_id,Timmings,window_seat,other_seat,driver_name,driver_details,ticket)";
        $query .= "VALUES(now(),'{$name}','{$bus_number}','{$agency_id}','{$Timmings}','{$window_seat}','{$other_seat}','{$driver_name}','{$driver_details}','{$ticket}')";
        if (execute($query))
        { ?>
        <script type="text/javascript">
            window.location = "bus.php";
        </script>
        <?php 
        }
        else
        { 
            $_SESSION['error_user'] = 1;
        ?>
           
        <script type="text/javascript">
            window.location = "bus.php";
        </script>
        <?php 
        }
}

function fetch($query)
{
    $result1 = array();
    $row = execute($query);
    while($result = mysqli_fetch_array($row,MYSQLI_ASSOC))
    {
       $return[] = $result;
    }
    return $return;
}

function execute($query)
{
   return mysqli_query($_SESSION['database_connection'],$query);
}
?>