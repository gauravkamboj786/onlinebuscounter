DOCUMENTATION:

    Documentation can be found in the <doc> directory of the archive file
	downloaded, including installation and usage.
	
		
EXAMPLES:

    Examples can be found in the <example> directory of the archive file
    downloaded. They are in html format. An internext connection is need
    in order to use jQuery and jQuery UI Style sheet from Google's CDN.

    
LAST UPDATED:

    |    $Date: 2012/08/05 19:40:31 $
    |  $Author: paulinho4u $
    |$Revision: 1.5 $
