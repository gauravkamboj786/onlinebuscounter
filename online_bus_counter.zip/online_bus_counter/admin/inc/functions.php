<?php
function start_session()
{
    session_start();
    $_SESSION['setup'] = 1;
}

function destroy_session()
{
    session_destroy();
    header("Location: index.php");
}

function is_session_started(){
    return (bool) (isset($_SESSION['setup']) && $_SESSION['setup'] == 1);
}

function redirect_to($location)
{
    header("Location:".$location); 
}

