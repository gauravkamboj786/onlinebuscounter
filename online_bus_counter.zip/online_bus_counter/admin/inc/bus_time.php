

                 	<option >0:30 Am</option>
                    <option >1:00 Am</option>
                    <option >1:30 Am</option>
                    <option >2:00 Am</option>
                    <option >2:30 Am</option>
                    <option >3:00 Am</option>
                    <option >3:30 Am</option>
                    <option >4:00 Am</option>
                    <option >4:30 Am</option>
                    <option >5:00 Am</option>
                    <option >5:30 Am</option>
                    <option >6:00 Am</option>
                    <option >6:30 Am</option>
                    <option >7:00 Am</option>
                    <option >7:30 Am</option>
                    <option >8:00 Am</option>
                    <option >8:30 Am</option>
                    <option >9:00 Am</option>
                    <option >9:30 Am</option>
                    <option >10:00 Am</option>
                    <option >10:30 Am</option>
                    <option >11:00 Am</option>
                    <option >11:30 Am</option>
                    <option >12:00 noon</option>
                    <option >12:30 Pm</option>
                    <option >13:00 Pm</option>
                    <option >13:30 Pm</option>
                    <option >14:00 Pm</option>
                    <option >14:30 Pm</option>
                    <option >15:00 Pm</option>
                    <option >15:30 Pm</option>
                    <option >16:00 Pm</option>
                    <option >16:30 Pm</option>
                    <option >17:00 Pm</option>
                    <option >17:30 Pm</option>
                    <option >18:00 Pm</option>
                    <option >18:30 Pm</option>
                    <option >19:00 Pm</option>
                    <option >19:30 Pm</option>
                    <option >20:00 Pm</option>
                    <option >20:30 Pm</option>
                     <option >21:00 Pm</option>
                    <option >21:30 Pm</option>
                    <option >22:00 Pm</option>
                    <option >22:30 Pm</option>
                    <option >23:00 Pm</option>
                    <option >23:30 Pm</option>
                     <option >24:00 mid night</option>
                    
                    
          

