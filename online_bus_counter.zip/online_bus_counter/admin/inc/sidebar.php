<nav class="navbar navbar-inverse navbar-static-top">
          <div class="container">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
            </div>
            <div id="navbar" class="navbar-collapse collapse">
              <ul class="nav navbar-nav">

                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Users <span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a href="user.php">Show User</a></li>
                    <li><a href="add_user.php">Add Users</a></li>
                    <li><a href="delete_user.php">Delete Users</a></li>
                    <li><a href="update_user.php">Update Users</a></li>
                  </ul>
                </li>
                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Agency <span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a href="agency.php">Show Agency</a></li>
                    <li><a href="add_agency.php">Add Agency</a></li>
                    <li><a href="delete_agency.php">Delete Agency</a></li>
                    <li><a href="update_agency.php">Update Agency</a></li>
                  </ul>
                </li>
                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Bus <span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a href="bus.php">Show Buses</a></li>
                    <li><a href="add_bus.php">Add Buses</a></li>
                    <li><a href="delete_bus.php">Delete Buses</a></li>
                    <li><a href="update_bus.php">Update Buses</a></li>
                  </ul>
                </li>
                <li class="dropdown">
                 <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Boarding point<span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a href="boarding_point.php">Boarding point</a></li>
                    <li><a href="add_boarding_point.php">Add Boarding point Buses</a></li>
                    <li><a href="delete_boarding_point.php">Delete Boarding point</a></li>
                    <li><a href="update_boarding_point.php">Update Boarding point</a></li>
                  </ul>
                </li>
                 <li class="dropdown">
                 <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Dropping point<span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a href="droping_point.php">Droping point</a></li>
                    <li><a href="add_droping_point.php">Add droping point</a></li>
                    <li><a href="delete_dropping_point.php">Delete droping point</a></li>
                    <li><a href="update_droping_point.php">Update droping point</a></li>
                  </ul>
                </li>
                 <li class="dropdown">
                 <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Routes<span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a href="routes.php">routes</a></li>
                    <li><a href="add_routes.php">Add routes</a></li>
                    <li><a href="delete_routes.php">Delete routes</a></li>
                    <li><a href="update_routes.php">Update routes</a></li>
                  </ul>
                </li>
                 <li class="dropdown">
                 <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Timming of buses<span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a href="timming.php">show timming</a></li>
                    <li><a href="add_timming.php">Add timming</a></li>
                    <li><a href="delete_timming.php">Delete timming</a></li>
                    <li><a href="update_timming.php">Update timming</a></li>
                  </ul>
                </li>
               <li class="dropdown">
                 <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Coupen<span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a href="coupen.php">Show Coupen</a></li>
                    <li><a href="add_coupen.php">Add Coupen</a></li>
                    <li><a href="delete_coupen.php">Delete Coupen</a></li>
                    </li>
                  </ul>
                </li>
                <li class="dropdown">
                 <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">personal coupen<span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a href="coupens.php">Show Coupens</a></li>
                    <li><a href="add_coupens.php">Add Coupens</a></li>
                    <li><a href="delete_coupens.php">Delete Coupens</a></li>
                    </li>
                  </ul>
                </li>
                <li class="dropdown">
                 <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">order table<span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a href="order.php">Show orders</a></li>
                    <li><a href="delete_order.php">Delete orders</a></li>
                </li>
             </ul>
          </li>
              
                 
                
              </ul>
            </div>
          </div>
        </nav>