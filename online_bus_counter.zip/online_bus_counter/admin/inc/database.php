<?php
include("functions.php");

function database_connection()
{
    if(!is_session_started())
    {
        start_session();
    }
    $_SESSION['database_connection'] = mysqli_connect("localhost","root","","obc");
}


function end_database_connection()
{
    if(isset($_SESSION['database_connection'])){
        mysqli_close($_SESSION['database_connection']);
    }
}

function authentication($username,$password)
{       
            $query = fetch("SELECT * FROM admin WHERE email = '{$username}' LIMIT 1");
            $get_email = $query[0]['email'];
            $get_password = $query[0]['password'];
            $get_id = $query[0]['id'];
        if( md5($password) == $get_password )
        {
            $_SESSION['admin'] = $username;
            $_SESSION['id'] = $get_id;
            $_SESSION['welcome'] = 1;
            redirect_to("dashboard.php");  
        }
        else 
        {
            $_SESSION['invalid_message'] = 1;
            redirect_to("index.php");
        }    
}


function signup($email,$password,$name,$contact)
{
        $query = "INSERT INTO users(email,password,name,mobile,created_at)";
        $query .= "VALUES('{$email}','".md5($password)."','{$name}','{$contact}',now())";
        if (execute($query))
        { ?>
        <script type="text/javascript">
            window.location = "user.php";
        </script>
        <?php 
        }
        else
        { 
            $_SESSION['error_user'] = 1;
        ?>
           
        <script type="text/javascript">
            window.location = "user.php";
        </script>
        <?php 
        }
}
function signup_agency($name,$mobile,$admin_id)
{
        $query = "INSERT INTO agency(name,mobile,created_at,admin_id)";
        $query .= "VALUES('{$name}','{$mobile}',now(),'{$admin_id}')";
        if (execute($query))
        { ?>
        <script type="text/javascript">
            window.location = "agency.php";
        </script>
        <?php 
        }
        else
        { 
            $_SESSION['error_user'] = 1;
        ?>
           
        <script type="text/javascript">
            window.location = "add_agency.php";
        </script>
        <?php 
        }
}
function add_bus($name,$bus_number,$agency_id,$Timmings,$window_seat,$other_seat,$driver_name,$driver_details,$ticket)
{
        $query = "INSERT INTO bus(created_at,name,bus_number,agency_id,Timmings,window_seat,other_seat,driver_name,driver_details,ticket)";
        $query .= "VALUES(now(),'{$name}','{$bus_number}','{$agency_id}','{$Timmings}','{$window_seat}','{$other_seat}','{$driver_name}','{$driver_details}','{$ticket}')";
        if (execute($query))
        { ?>
        <script type="text/javascript">
            window.location = "bus.php";
        </script>
        <?php 
        }
        else
        { 
            $_SESSION['error_user'] = 1;
        ?>
           
        <script type="text/javascript">
            window.location = "bus.php";
        </script>
        <?php 
        }
}
function boarding_point($name,$city_id)
{
        $query = "INSERT INTO boarding_point(point_name,city_id,created_at)";
        $query .= "VALUES('{$name}','{$city_id}',now())";
		
        if (execute($query))
        { ?>
        <script type="text/javascript">
             window.location = "boarding_point.php";
        </script>
        <?php 
        }
        else
        { 
            $_SESSION['error_user'] = 1;
        ?>
           
        <script type="text/javascript">
            window.location = "add_agency.php";
        </script>
        <?php 
        }
}
function dropping_point($name,$city_id)
{
        $query = "INSERT INTO dropping_point(point_name,city_id,created_at)";
        $query .= "VALUES('{$name}','{$city_id}',now())";
		
       if (execute($query))
				{ ?>
				<script type="text/javascript">
					 window.location = "droping_point.php";
				</script>
				<?php 
        }
        else
				{ 
					$_SESSION['error_user'] = 1;
				?>
				   
				<script type="text/javascript">
					window.location = "add_dropping_point.php";
				</script>
				<?php 
        }
}
function routes($id,$boarding_point_id,$dropping_point_id)
{
        $query = "INSERT INTO routes(created_at,bus_id,boarding_point_id,dropping_point_id)";
        $query .= "VALUES(now(),'{$id}','{$boarding_point_id}','{$dropping_point_id}')";
		
       if (execute($query))
				{ ?>
				<script type="text/javascript">
					 window.location = "routes.php";
				</script>
				<?php 
        }
        else
				{ 
					$_SESSION['error_user'] = 1;
				?>
				   
				<script type="text/javascript">
					window.location = "add_routes.php";
				</script>
				<?php 
        }
		
}
function  timming($from_bus_time,$bus_to_time,$route_id,$Day)
{
 $query = "INSERT INTO timming(from_bus_time,bus_to_time,route_id,Day)";
        $query .= "VALUES('{$from_bus_time}','{$bus_to_time}','{$route_id}','{$Day}')";
		
       if (execute($query))
				{ ?>
				<script type="text/javascript">
					 window.location = "timming.php";
				</script>
				<?php 
        }
        else
				{ 
					$_SESSION['error_user'] = 1;
				?>
				   
				<script type="text/javascript">
					window.location = "add_timming.php";
				</script>
				<?php 
        }
}

function coupen($name,$discount)
{  
		$query="INSERT INTO COUPEN(coupen_name,coupen_discount,created_at)";
		$query.="values('{$name}','{$discount}',now())";
		if (execute($query))
		{ ?>
				<script type="text/javascript">
					 window.location = "coupen.php";
				</script>
				<?php 
        }
        else
		{ 
					$_SESSION['error_user'] = 1;
				?>
				   
				<script type="text/javascript">
					window.location = "add_coupen.php";
				</script>
				<?php 
        }
}
function coupens($name,$discount)
{  
		$query="INSERT INTO COUPENS(coupen_name,coupen_discount,created_at)";
		$query.="values('{$name}','{$discount}',now())";
		if (execute($query))
		{ ?>
				<script type="text/javascript">
					 window.location = "coupens.php";
				</script>
				<?php 
        }
        else
		{ 
					$_SESSION['error_user'] = 1;
				?>
				   
				<script type="text/javascript">
					window.location = "add_coupens.php";
				</script>
				<?php 
        }
}

function fetch($query)
{
    $result1 = array();
    $row = execute($query);
    while($result = mysqli_fetch_array($row,MYSQLI_ASSOC))
    {
       $return[] = $result;
    }
    return $return;
}

function execute($query)
{
   return mysqli_query($_SESSION['database_connection'],$query);
}
?>