<nav class="navbar navbar-default navbar-inverse navbar-fixed-bottom">
  <div class="container">
      <p class="mgtop10 text-primary" style="margin-top:15px;">Copyright &COPY; 2015 GOIT SOLUTIONS PUNJAB</p>
  </div>
</nav>