 <div class="container mgtop70">
    	<div class="col-lg-12 mgtop70">
        	<div class="col-lg-4  text-center text-primary">
            	<p class="glyphicon glyphicon-sort" style="font-size:100px;"></p>
                <p>GET UPTO 50% OFF ON ROUND TRIP</p>
            </div>
        	<div class="col-lg-4  text-center text-primary">
            	<p class="glyphicon glyphicon-briefcase" style="font-size:100px;"></p>
                <p>100% SECURE ONLINE PAYMENT</p>
            </div>
        	<div class="col-lg-4  text-center text-primary">
            	<p class="glyphicon glyphicon-move" style="font-size:100px;"></p>
                <p>TRACK BUS WITH ONLINE BUS COUNTER</p>
            </div>
        </div>
    </div>