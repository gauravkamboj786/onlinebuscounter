<?php
ini_set("display_errors", 1);
include("inc/database.php");
    start_session();
    database_connection();
    destroy_session();
    end_database_connection();
?>