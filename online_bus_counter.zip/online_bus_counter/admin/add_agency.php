<?php
	include("inc/database.php");
	start_session();	
	database_connection();
	if(!isset($_SESSION['admin']))
	{
		redirect_to("index.php");
	}	
	
 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<?php include("inc/scripts.php"); ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Bus Counter</title>
</head>

<body>
	<?php include("inc/navigation.php"); ?>
    <div class="container">
        <?php include("inc/sidebar.php"); ?>
        <div class="row">
        <div class="container col-xs-offset-4 col-lg-4 col-xs-offset-4" style="background:rgba(0,0,0,1); border-radius:20px; margin-top:-10px; padding-bottom: 30px;">       
            <form class="form-signin mgtop10" action="add_agency.php?add=1" method="post">
                <h2 style="color:white;">ADD NEW AGENCY</h2>
                <input type="text" id="inputEmail" class="form-control" placeholder="Enter Name of agency" name="name" required autofocus><br/>
                <input type="int" id="inputEmail" class="form-control" placeholder="mobile" name="mobile" required autofocus><br/>
                
                <label></label>
                <button class="btn btn-info form-control center-block mgtop10" type="submit">Register</button>
              </form>   
      </div>
    </div>    
    </div>    
 
   
	<?php include("inc/footer.php"); ?>
	
</body>
</html>
<?php 
    if(isset($_GET['add']) && $_GET['add'] == 1)
    {
        signup_agency($_POST['name'],$_POST['mobile'],$_SESSION['id']);
    }
?>

<?php end_database_connection(); ?>