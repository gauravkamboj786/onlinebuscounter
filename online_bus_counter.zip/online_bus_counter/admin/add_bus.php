<?php
	include("inc/database.php");
	start_session();	
	database_connection();
	if(!isset($_SESSION['admin']))
	{
		redirect_to("index.php");
	}	
	
 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
		
	<?php include("inc/scripts.php"); ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Bus Counter</title>
</head>

<body>
	<?php include("inc/navigation.php"); ?>
    <div class="container" style="margin-bottom: 50px;">
        <?php include("inc/sidebar.php"); ?>
        <div class="row">
        <div class="container col-xs-offset-4 col-lg-4 col-xs-offset-4" style="background:rgba(0,0,0,1); border-radius:20px; margin-top:-10px; padding-bottom: 30px;">       
            <form class="form-signin mgtop10" action="add_bus.php?add=1" method="post">
                <h2 style="color:white;">Add New Bus</h2>
                <select class="form-control" name="agency_id">
                    <option>SELECT AGENCY</option>
               <?php 			 
                  foreach(fetch("SELECT * FROM agency") as $agent)
                    { ?>                    
                    <option value="<?=$agent['id']?>"><?=$agent['name']?></option>
                <?php    
                    }
                ?>
                </select><br/>
                <input type="text" name="name" class="form-control" placeholder="Enter Bus Name"/><br/>
                <input type="text" name="bus_number" class="form-control" placeholder="Enter Bus Number"/><br/>
                 <input type="text" name="window_seat" class="form-control" placeholder="Enter Window Seats"/><br/>
                <?php include("inc/timming.php"); ?>
                <input type="text" name="other_seat" class="form-control" placeholder="Enter  Other Seats"/><br/>
               <input type="text" name="driver_name" class="form-control" placeholder="Enter Driver's Name"/><br/>
                <input type="text" name="driver_details" class="form-control" placeholder="Enter Driver Details"/><br/>
                <input type="text" name="ticket" class="form-control" placeholder="Enter Ticket Price INR"/><br/>
                <label></label>
                <button class="btn btn-info form-control center-block mgtop10" type="submit">Register</button>
              </form>   
      </div>
    </div>    
    </div>    
 
   
	<?php include("inc/footer.php"); ?>
	
</body>
</html>
<?php 
    if(isset($_GET['add']) && $_GET['add'] == 1)
    {
        add_bus($_POST['name'],$_POST['bus_number'],$_POST['agency_id'],$_POST['Timmings'],$_POST['window_seat'],$_POST['other_seat'],
		$_POST['driver_name'],$_POST['driver_details'],$_POST['ticket']);
		
    }
?>

<?php end_database_connection(); ?>