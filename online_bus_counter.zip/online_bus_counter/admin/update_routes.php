<?php
	include("inc/database.php");
	start_session();	
	database_connection();
	if(!isset($_SESSION['admin']))
	{
		redirect_to("index.php");
	}	
	
 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<?php include("inc/scripts.php"); ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Bus Counter</title>
</head>

<body>
	<?php include("inc/navigation.php"); ?>
    <div class="container" >
        <?php include("inc/sidebar.php"); ?>
       <div class="row">
        <div class="col-lg-12" style="font-size: 14px;">
          <div class="panel panel-primary" style="margin-bottom: 50px;">
            <div class="panel-heading">
              <h3 class="panel-title">update route</h3>
            </div>
           	 <div class="panel-body">
               
              <div class="col-lg-9">
                       <form class="form-signin mgtop10" action="update_routes.php?add=1" method="post">
                       	<select class="form-control" name="bus">
                            <option>SELECT bus</option>
                       <?php 			 
                          foreach(fetch("SELECT * FROM bus") as $agent)
                            { ?>                    
                            <option value="<?=$agent['id']?>"><?=$agent['name']?>(<?=$agent['bus_number']?>)</option>
                        <?php    
                            }
                        ?>
                       
                        </select>
                        
                </div>
                           <div class="col-lg-1"></div>
                           <div class="col-lg-2">
                                 <button class="btn btn-success">search</button>   

                            </div>
                       </div> 
                           
                    </div>
                  </div>
                </div>
                                    
                </div>    
                    </form>
                    
     <?php  if(isset($_GET['add']) && $_GET['add'] == 1)
	 			{	?>	
                	<div class="container">
                	 <div class="panel panel-primary">
                              <div class="panel-heading">
                   		          <h3 class="panel-title">Detail of buses</h3>
                             </div>
                       <div class="panel-body" style="margin-bottom:18px;" >   
                               
                                <div class="col-lg-6 thumbnail" style="margin-bottom:15px;"> 
                                        <div class="col-lg-4"><b>Boarding point</b></div>
                                        <div class="col-lg-4"><b>Droping point</b></div>
                                         <div class="col-lg-4"><b>Update</b></div>
                                 </div>  
								 <div class="col-lg-6 thumbnail" style="margin-bottom:15px;"> 
                                        <div class="col-lg-4"><b>Boarding point</b></div>
                                        <div class="col-lg-4"><b>Droping point</b></div>
                                          <div class="col-lg-4"><b>Update</b></div>
                                 </div>  
		
	    						
						 <?php
						  foreach(fetch("SELECT * FROM routes where bus_id=".$_POST['bus']." ") as $agent)
								{ 			
											  ?>
                                	            
                                    		<div class="col-lg-6 thumbnail" style="margin-bottom:15px;" > 
                                              <?php  foreach(fetch("SELECT * FROM cities where city_id=".$agent['boarding_point_id']."") as $agen)
														{ ?>                    
																<div class="col-lg-4"><?php echo $agen['city_name'] ?></div>
                                                                 
                                                                
													<?php    
														}
													?>
                                              <?php  foreach(fetch("SELECT * FROM cities where city_id=".$agent['dropping_point_id']."") as $agen)
														{ ?>                    
																<div class="col-lg-4"><?php echo $agen['city_name'] ?></div>
                                                                 
                                                                
													<?php    
														}
											?>  <div class="col-lg-4">
                                            <?php echo "<a href='update_routes.php?id=".$agent['id']."'><span class='glyphicon                                                  glyphicon-edit'style='font-size:30px;'></span></a>";  ?>
                                                </div>
                                           
								  </div><?php
								}
	               			}
							
							 ?>
                            	
                      </div>
				  </div>
                </div> 
<?php                
 if(isset($_GET['id']))
    {
foreach(fetch("SELECT * FROM routes WHERE id = ".$_GET['id']."  LIMIT 1") as $user)
            {
                $getboarding = $user['boarding_point_id'];
				 $getdroping = $user['dropping_point_id'];
                
            }
            ?>
        <div class="container col-xs-offset-4 col-lg-4 col-xs-offset-4" style="background:rgba(0,0,0,1); border-radius:20px; margin-top:-10px; 														                  padding-bottom: 40px;margin-bottom: 100px;">       
                <form class="form-signin mgtop10" action="update_routes.php?update=<?=$_GET['id']?>" method="post">
                <h2 style="color:white;">Update</h2>
                 <select class="form-control" name="boarding_point_id" >
                <option>select boarding point</option>
               <?php foreach(fetch("select * from cities")as $agent)
			   { ?>
                
                	<option value="<?=$agent['city_id']?>"><?=$agent['city_name']?> (<?=$agent['city_state']?>)</option>
               
               <?php }
				?>
                </select>
                <select class="form-control" style="margin-top:20px;" name="dropping_point_id">
                <option>select droping point</option>
                       <?php 	foreach(fetch("select * from cities")as $agent)
					   				{?>
                                    	<option value="<?=$agent['city_id']?>"><?=$agent['city_name']?> (<?=$agent['city_state']?>)</option>	
                                    
									<?php 
                                    }
					   ?>
                        
                       
                      
                 </select>
               
              	
                <label></label>
                <button class="btn btn-info form-control center-block mgtop10" type="submit">Update</button>
              </form>   
      </div>        <?php     
    }
?>  
<?php 
    if(isset($_GET['update']))
   		 {
				$query = "UPDATE routes SET boarding_point_id='".$_POST['boarding_point_id']."',dropping_point_id='".$_POST['dropping_point_id']."'
				  WHERE id =".$_GET['update']." LIMIT 1 ";
			 		execute($query);
				
				?>
				<script type="text/javascript">
				  window.location = "update_routes.php";
				</script>
				<?php     
			}
?>                           
                
                 
			
	<?php include("inc/footer.php"); ?>
</body>
</html>
<?php end_database_connection(); ?>