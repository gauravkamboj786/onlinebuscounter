<?php
	include("inc/database.php");
	start_session();	
	database_connection();
	if(!isset($_SESSION['admin']))
	{
		redirect_to("index.php");
	}
        if(isset($_GET['activate']) && $_GET['activate'] == 0)
        {
            $query = "UPDATE users SET activate = 0 WHERE id = ".$_GET['id']."  ";
            execute($query);
            redirect_to("user.php");
        }
        if(isset($_GET['activate']) && $_GET['activate'] == 1 )
        {
            $query = "UPDATE users SET activate = 1 WHERE id = ".$_GET['id']."  ";
            execute($query);
            redirect_to("user.php");
        }
	
	
 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<?php include("inc/scripts.php"); ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Bus Counter</title>
</head>

<body>
	<?php include("inc/navigation.php"); ?>
    
    
    <div class="container">
        <?php include("inc/sidebar.php"); ?>
        <?php 
        if(isset($_GET['id']))
        { 
            foreach(fetch("SELECT * FROM users WHERE id = ".$_GET['id']."  LIMIT 1") as $user)
            {
                $getname = $user['name'];
                $getemail = $user['email'];
                $getmobile = $user['mobile'];
            }
            ?>
        <div class="container col-xs-offset-4 col-lg-4 col-xs-offset-4" style="background:rgba(0,0,0,1); border-radius:20px; margin-top:-10px; padding-bottom: 30px;">       
            <form class="form-signin mgtop10" action="update_user.php?update=<?=$_GET['id']?>" method="post">
                <h2 style="color:white;">Update</h2>
                <input type="text" id="inputEmail" class="form-control" placeholder="Enter Your Full Name" name="name" value="<?=$getname?>" 	                required autofocus><br/>
                <input type="email" id="inputEmail" class="form-control" placeholder="Email address" name="email" value="<?=$getemail?>" required                  autofocus><br/>
                <input type="text" id="inputEmail" class="form-control" name="mobile" placeholder="Mobile Number" value="<?=$getmobile?>" required                 autofocus><br/>
                <input type="password" id="inputPassword" class="form-control" placeholder="Password" name="password"  required>
                <label></label>
                <button class="btn btn-info form-control center-block mgtop10" type="submit">Update</button>
              </form>   
      </div>
        <?php 
        }
        else 
        { ?>
        <div class="col-lg-12" style="font-size: 14px;">
        <div class="panel panel-primary">
            <div class="panel-heading">
              <h3 class="panel-title">Users</h3>
            </div>
            <div class="panel-body">
                <div class="col-lg-12">
                    <div class="col-lg-12 thumbnail"> 
                        <div class="col-lg-3"><b>Name</b></div>
                        <div class="col-lg-4"><b>Email</b></div>
                        <div class="col-lg-3"><b>Contact</b></div>
                        <div class="col-lg-2"><b>Update</b></div>
                    </div>
                <?php 
                    foreach(fetch("SELECT * FROM users  LIMIT 10") as $user)
                    { ?>                    
                    <div class="col-lg-12 thumbnail"> 
                        <div class="col-lg-3"><?=$user['name']?></div>
                        <div class="col-lg-4"><?=$user['email']?></div>
                        <div class="col-lg-3"><?=$user['mobile']?></div>
                        <div class="col-lg-2">
                            <?php 
                                    echo "<a href='update_user.php?id=".$user['id']."'><span class='glyphicon glyphicon-edit' style='font-size:30px;'></span></a>";
                            ?>
                            
                        </div>
                    </div>
                    
                <?php    }
                ?>
                </div>    
            </div>
          </div>
            
        </div>
        <?php } ?>
    </div>    
 
   
	<?php include("inc/footer.php"); ?>
	
</body>
</html>
<?php 
    if(isset($_GET['update']))
    {
        $query = "UPDATE users SET email='".$_POST['email']."' , name='".$_POST['name']."' , mobile='".$_POST['mobile']."' , password ='".md5($_POST['password'])."' WHERE id =".$_GET['update']." LIMIT 1 ";
        execute($query);
    ?>
        <script type="text/javascript">
            window.location = "update_user.php";
        </script>
        <?php     
    }
?>
<?php end_database_connection(); ?>
