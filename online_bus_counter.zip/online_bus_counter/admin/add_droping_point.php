<?php
	include("inc/database.php");
	start_session();	
	database_connection();
	if(!isset($_SESSION['admin']))
	{
		redirect_to("index.php");
	}	
	
 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<?php include("inc/scripts.php"); ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Bus Counter</title>
</head>

<body>
	<?php include("inc/navigation.php"); ?>
    <div class="container">
        <?php include("inc/sidebar.php"); ?>
        <div class="row">
       		 <div class="col-lg-12" style="font-size: 14px;">
       				 <div class="panel panel-primary"">
           				 <div class="panel-heading">
                                   <h3 class="panel-title">Show droping points</h3>
            			</div>
           					 <div class="panel-body">
               
              			<div class="col-lg-12">
                       	<form class="form-signin mgtop10" action="add_droping_point.php?add=1" method="post">
                       		<select class="form-control" name="city_id">
                            <option>Select city</option>
                       <?php 			 
                          foreach(fetch("SELECT * FROM cities") as $agent)
                            { ?>                    
                            <option value="<?=$agent['city_id']?>"><?=$agent['city_name']?>(<?=$agent['city_state']?>)</option>
                        <?php    
                            }
                        ?>
                        </select>
                         
                    <h2 style="color:Black;">Add new Boarding point</h2>
                <input type="text" id="inputEmail" class="form-control" placeholder="Point name" name="name" required autofocus><br/>
              <button class="btn btn-info form-control center-block mgtop10" type="submit">Register</button>
              
                        </form></div>   
                    </div>
                  </div>
                </div>
                                    
                </div>    
                   
   
	    
       
   
	<?php include("inc/footer.php"); ?>
	
</body>
</html>
<?php 

    if(isset($_GET['add']) && $_GET['add'] == 1)
    {
       dropping_point($_POST['name'],$_POST['city_id']);
	
    }
?>

<?php end_database_connection(); ?>