<?php
        if(isset($_SESSION['username']))
	{
		redirect_to("dashboard.php");
	}	

	include("inc/database.php");
	start_session();	
	database_connection();
        authentication($_POST['email'],$_POST['password']);
?>


	