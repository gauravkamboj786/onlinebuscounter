<?php
	include("inc/database.php");
	start_session();		
	database_connection();
      
 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Bus Counter</title>
<?php include("inc/scripts.php"); ?>
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
<script src="//code.jquery.com/jquery-1.10.2.js"></script>
<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
<link rel="stylesheet" href="/resources/demos/style.css">
<script type="text/javascript">
 $(function() {
    $( "#datepicker" ).datepicker();
  });
</script>

</head>

<body style="background:#FFFFFF;">
<?php include("inc/navigation.php"); ?>
        <?php include("inc/messages.php"); ?>
<div class="container" style="background:rgba(0,0,0,0.6); border-radius:20px; margin-top:-10px;">
    	<h1 class=" col-lg-12 text-center"  style="color:#FFFFFF;">INDIA'S LARGEST REAL TIME TICKETS BOOKING SERVICE </h1>
        <div class=" col-lg-12" style="margin-top:10px;">
        	<form action="search.php?add=1" method="post">
            	<div class="form-group col-lg-3">
                	<label style="color:#FFFFFF;">From</label>
                    	<select class="form-control" name="boarding_city">
                                <option>select city</option>
                               <?php 
                                foreach(fetch("select * from cities") as $cities) 
                                {?>
                                <option value="<?php echo $cities['city_id'] ?>"><?php echo $cities['city_name']; ?></option>
                               <?php }
                               ?>
                         </select>
        		
                </div>
            	<div class="form-group col-lg-3">
                	<label  style="color:#FFFFFF;">To</label>
                    <select class="form-control" name="droping_point">
                            <option>select city</option>
                             <?php foreach(fetch("select * from cities") as $cities)
                             { ?>
                                <option value="<?php echo $cities['city_id'] ?>" ><?php echo $cities['city_name']; ?></option>
                            <?php }?>
                    </select>
                </div>
                <div class="form-group col-lg-3">
                	<label style="color:#FFFFFF;">Date Of Journey</label>
                     <input type="text" id="datepicker" name="going" class="form-control" placeholder="Enter the date of journey">
                </div>
                <div class="form-group col-lg-3" >
                	<label style="color:#000000;">'</label>
                    <input type="submit" class="btn btn-primary pull-right form-control" value="Search Bus" />
                </div>
                <div class="form-group">
                	
                </div>
            </form>
        </div>
    </div>
<div class="container" style="margin-top:40px;">
    <div class="col-lg-4">
    </div>
    <div class="col-lg-4">	
   <?php if(isset($_SESSION['username'])) 
   		{	    ?>
            <form action="cancel_ticket.php?delete=1" method="post">
            <label style="color:#666666"><h5><center>Type your ticket number</center></h5></label>
            <input type="text" class="form-control" name="ticket_no" placeholder="type your ticket number" autofocused/>
             <button class="btn btn-info" style="margin-top:20px;margin-bottom:20px;" type="submit">Cancel the ticket</button>
            </form>
  <?php	}?>
     <?php if(!isset($_SESSION['username'])) 
     	{?>
         <form action="cancel_ticket.php?delete=1" method="post">
            <label style="color:#666666"><h5><center>Type your ticket number</center></h5></label>
            <input type="text" class="form-control" name="ticket_no" placeholder="type your ticket number" autofocused/>
            <label>enter your email from which you have booked the ticket</label>
            <input type="text" class="form-control" name="email" placeholder="Enter your email address" autofocused/>
            <button class="btn btn-info" style="margin-top:20px;margin-bottom:20px;" type="submit">Cancel the ticket</button>
            </form>
     <?php  } ?> 	
     </div>
     <div class="col-lg-4">
     </div>       
</div>    
<?php
if(isset($_GET['delete']))
{   
	 $a=$_POST['ticket_no']/2;
	 
			if(isset($_SESSION['username']))
				{
				$to=$_SESSION['username'];	
				$subject = 'the subject';
						$message = "Please Click The Link Below to delete the ticket<br/> <a href='http://onlinebuscounter.com/cancel_ticket.php?cancel=".$a."'>Verify Account</a>";
						$headers = 'From: donotreply@onlinebuscounter.com' . "\r\n" .
				'Reply-To: onlinebuscounter@gmail.com' . "\r\n" .
				'X-Mailer: PHP/' . phpversion();
			
					 mail($to, $subject, $message, $headers);
					$_SESSION['confirm'] = 1;
            		redirect_to("index.php");
				}	

	 
	 
	 
if(!isset($_SESSION['username']))
		{		$a=$_POST['ticket_no']/2;	
				$query_fetch ="select * from order_table where email='".$_POST['email']."', and id='".$_POST['$a']."' ";
				if(fetch($query_fetch))
					{			
			
				
							$to=$_POST['email'];	
							$subject = 'the subject';
						$message = "Please Click The Link Below to delete the ticket<br/> <a href='http://onlinebuscounter.com/cancel_ticket.php?cancel=".$a."'>Verify Account</a>";
						$headers = 'From: donotreply@onlinebuscounter.com' . "\r\n" .
							'Reply-To: onlinebuscounter@gmail.com' . "\r\n" .
							'X-Mailer: PHP/' . phpversion();
						
								 mail($to, $subject, $message, $headers);
								 $_SESSION['confirm'] = 1;
            					redirect_to("index.php");
					 }
				else
					{
						?><h2>sorry you have registered with another mail or may be you are enteru=ing wrong ticket no.</h2><?php
					}	 
		}	

}
?>
<?php
if(isset($_GET['cancel']))
{	
	 $query = "DELETE FROM order_table WHERE id = {$_GET['cancel']} LIMIT 1";
        execute($query);
    ?>
        <script type="text/javascript">
            window.location = "index.php";
        </script><?php
}
?>

</body>
</html>
