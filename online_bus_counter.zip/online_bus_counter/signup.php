<?php
	include("inc/database.php");
	start_session();	
	database_connection();
        if(isset($_SESSION['username']))
	{
		redirect_to("dashboard.php");
	}	

 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<?php include("inc/scripts.php"); ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Bus Counter</title>
</head>

<body>
	<?php include("inc/navigation.php"); ?>
  <div class="row">
        <div class="container col-xs-offset-4 col-lg-4 col-xs-offset-4" style="background:rgba(0,0,0,0.6); border-radius:20px; margin-top:-10px; padding-bottom: 30px;">       
            <form class="form-signin mgtop10" action="signup-process.php" method="post">
                <h2 style="color:white;">Register To Online Bus Counter</h2>
                <input type="text" id="inputEmail" class="form-control" placeholder="Enter Your Full Name" name="name" required autofocus><br/>
                <input type="email" id="inputEmail" class="form-control" placeholder="Email address" name="email" required autofocus><br/>
                <input type="text" id="inputEmail" class="form-control" name="mobile" placeholder="Mobile Number" required autofocus><br/>
                <input type="password" id="inputPassword" class="form-control" placeholder="Password" name="password" required>
                <label><a href="recovery.php" class="text-primary text-center">Forget Password ?</a></label>
                <button class="btn btn-info form-control center-block mgtop10" type="submit">Register</button>
              </form>   
      </div>
    </div>    
    
 	<?php include("inc/footer.php"); ?>
	
</body>
</html>
