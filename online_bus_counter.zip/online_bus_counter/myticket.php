<?php
	include("inc/database.php");
	start_session();		
	database_connection();
      
 ?>
<!DOCTYPE html PUBLIC "-//W3C//D XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/D/xhtml1-transitional.d">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Bus Counter</title>
<?php include("inc/scripts.php"); ?>
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
<script src="//code.jquery.com/jquery-1.10.2.js"></script>
<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
<link rel="stylesheet" href="/resources/demos/style.css">
<script type="text/javascript">
 $(function() {
    $( "#datepicker" ).datepicker();
  });
</script>

</head>

<body style="background:#FFFFFF;">
<?php include("inc/navigation.php"); ?>
        <?php include("inc/messages.php"); ?>
<div class="container" style="background:rgba(0,0,0,0.6); border-radius:20px; margin-top:-10px;">
    	<h1 class=" col-lg-12 text-center"  style="color:#FFFFFF;">INDIA'S LARGEST REAL TIME TICKETS BOOKING SERVICE </h1>
        <div class=" col-lg-12" style="margin-top:10px;">
        	<form action="search.php?add=1" method="post">
            	<div class="form-group col-lg-3">
                	<label style="color:#FFFFFF;">From</label>
                    	<select class="form-control" name="boarding_city">
                                <option>select city</option>
                               <?php 
                                foreach(fetch("select * from cities") as $cities) 
                                {?>
                                <option value="<?php echo $cities['city_id'] ?>"><?php echo $cities['city_name']; ?></option>
                               <?php }
                               ?>
                         </select>
        		
                </div>
            	<div class="form-group col-lg-3">
                	<label  style="color:#FFFFFF;">To</label>
                    <select class="form-control" name="droping_point">
                            <option>select city</option>
                             <?php foreach(fetch("select * from cities") as $cities)
                             { ?>
                                <option value="<?php echo $cities['city_id'] ?>" ><?php echo $cities['city_name']; ?></option>
                            <?php }?>
                    </select>
                </div>
                <div class="form-group col-lg-3">
                	<label style="color:#FFFFFF;">Date Of Journey</label>
                     <input type="text" id="datepicker" name="going" class="form-control" placeholder="Enter the date of journey">
                </div>
                <div class="form-group col-lg-3" >
                	<label style="color:#000000;">'</label>
                    <input type="submit" class="btn btn-primary pull-right form-control" value="Search Bus" />
                </div>
                <div class="form-group">
                	
                </div>
            </form>
        </div>
    </div>
<div class="container" style="margin-top:50px;">
	
    <div class="col-lg-12">
						<?php
                        if(isset($_SESSION['username']))
                        {?><table border="1" style="width:100%">
                        	<thead>
                            <tr>
                                <th>Your ticket number</th>
                                <th>name</th>
                                <th>fare</th>
                                <th>no of seat</th>
                                <th>other seat no</th>
                                <th>date of journey</th>
                                <th>window seat number</th>
                                <th>departure time</th>
                                <th>cancel ticket</th>
                            </tr>		
                            </thead>
                            
                        <?php
                          $query_fetch ="select * from order_table where email='".$_SESSION['username']."'";
                          if(fetch($query_fetch))
                          {
                            foreach(fetch($query_fetch) as $myticket)
                                {
                                    $a=$myticket['id']*2;
                                    ?><tbody>
                                        <tr>	
                                            <th><?php echo $a ?></th>
                                            <th><?php echo $myticket['name']; ?></th>
                                            <th><?php echo $myticket['fare']; ?></th>
                                            <th><?php echo $myticket['no_of_seat']; ?></th>
                                            <th><?php echo $myticket['other_seat_no']; ?></th>
                                            <th><?php echo $myticket['date_of_journey']; ?></th>
                                            <th><?php echo $myticket['window_seat_no']; ?></th>
                                            <th><?php echo $myticket['from_bus_time']; ?></th>
                                            <th><a href="cancel_ticket.php">cancel</a></th>
                                       </tr>
                                      </tbody> 
                                    <?php
                                }
                          }
                        }
                        ?></table>
        </div>
      
  </div>                  

</body>
</html>
