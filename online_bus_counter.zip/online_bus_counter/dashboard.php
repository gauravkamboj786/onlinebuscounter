<?php
	include("inc/database.php");
	start_session();	
	database_connection();
	
	
 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<?php include("inc/scripts.php"); ?>
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
<script src="//code.jquery.com/jquery-1.10.2.js"></script>
<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>    
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="/resources/demos/style.css">
<script type="text/javascript">
 $(function() {
    $( "#datepicker" ).datepicker();
  });
 

</script>
<title>Online Bus Counter</title>
</head>

<body>
	<?php include("inc/navigation.php"); ?>
        <?php include("inc/messages.php"); ?>
<div class="container" style="background:rgba(0,0,0,0.6); border-radius:20px; margin-top:-10px;">
    	<h1 class=" col-lg-12 text-center"  style="color:#FFFFFF;">INDIA'S LARGEST REAL TIME TICKETS BOOKING SERVICE </h1>
        <div class=" col-lg-12" style="margin-top:10px;">
        	<form action="search.php?add=1" method="post">
            	<div class="form-group col-lg-3">
                	<label style="color:#FFFFFF;">From</label>
                    	<input list="cities" name="boarding_city" placeholder="Enter Your City" class="form-control" required/>
                                <datalist id="cities" >
									<?php 
                                    foreach(fetch("select * from cities") as $cities) 
                                    {?>
                                       <option value="<?php echo $cities['city_name']; ?>" />
                                    <?php }
                                    ?>
                                </datalist>        		
                </div>
            	<div class="form-group col-lg-3">
                	<label  style="color:#FFFFFF;">To</label>
                    <input list="cities" name="droping_point" placeholder="Enter Your City" class="form-control" required/>
                                <datalist id="cities" >
									<?php 
                                    foreach(fetch("select * from cities") as $cities) 
                                    {?>
                                       <option value="<?php  echo $cities['city_name']; ?>" >
                                    <?php }
                                    ?>
                                </datalist>  
                </div>
                <div class="form-group col-lg-3">
                	<label style="color:#FFFFFF;">Date Of Journey</label>
                     Date: <input type="text" id="datepicker" name="going" class="form-control" placeholder="Enter the date of journey" required>
                </div>
                <div class="form-group col-lg-3" >
                	<label style="color:#000000;">'</label>
                    <input type="submit" class="btn btn-primary pull-right form-control" value="Search Bus" />
                </div>
                <div class="form-group">
                	
                </div>
            </form>
        </div>
    <div class="col-lg-12" style="margin-top:20px;">
            <div class="col-lg-4 text-center" style="color:#fff;">
                <p class="glyphicon glyphicon-user" style="font-size:100px"></p>
                <p>No Hassle with Bus Travel Agents</p>
            </div>
            <div class="col-lg-4 text-center" style="color:#fff;">
                <p class="glyphicon glyphicon-hand-up" style="font-size:100px"></p>
                <p>100% Live Bus Ticket Inventory</p>
            </div>
            <div class="col-lg-4 text-center" style="color:#fff;">
                <p class="glyphicon glyphicon-ok" style="font-size:100px"></p>
                <p>Reserved Bus Seats for Ladies</p>
            </div>
        </div>
    </div>

   
	
	
<?php include("inc/footer.php"); ?>
	
</body>
</html>
<?php end_database_connection(); ?>