<?php
	include("inc/database.php");
	start_session();		
	database_connection();
      
 ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Online Bus Counter</title>
<?php include("inc/scripts.php"); ?>
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
<script src="//code.jquery.com/jquery-1.10.2.js"></script>
<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
<link rel="stylesheet" href="/resources/demos/style.css">
<script type="text/javascript">
 $(function() {
    $( "#datepicker" ).datepicker();
  });
var seats = [];
function handler()
{  if(this.checked==true)
	{
		  seats.push(this.id);
		 
		 var value=seats;
		 document.getElementById("demo").innerHTML = value; 
		 document.getElementById("seat_no").value = seats;
		 document.getElementById("number_of_seat").value = seats.length;
		 
	}
	if(this.checked==false)
	{	for(i=0;i<seats.length;i++)
			{ 
				if(this.id==seats[i])
					{ seats.splice(i,1);
						 
						 document.getElementById("demo").innerHTML = seats; 
						 document.getElementById("seat_no").value = seats;
						 document.getElementById("number_of_seat").value = seats.length;
					}
			}
		
		 
	} 
	 
}
var otherseats=[];
function otherhandler()
{ if(this.checked==true)
	{
		  otherseats.push(this.id);
		 
		 
		 document.getElementById("demo1").innerHTML = otherseats; 
		 document.getElementById("seat_no1").value = otherseats;
		 document.getElementById("number_of_seat1").value = otherseats.length;
	}
	if(this.checked==false)
	{	for(j=0;j<otherseats.length;j++)
			{ 
				if(this.id==otherseats[j])
					{ otherseats.splice(j,1);
						 
						 document.getElementById("demo1").innerHTML = otherseats; 
						 document.getElementById("seat_no1").value = otherseats;
						 document.getElementById("number_of_seat1").value = otherseats.length;
					}
			}
		
		 
	} 
	
}  
</script>

</head>

<body style="background:#FFFFFF;">
<?php include("inc/navigation.php"); ?>
        <?php include("inc/messages.php"); ?>

 <?php
if(isset($_GET['add']))

{ 
	if(isset($_POST['going']))
		{
			if($_POST['going']!=null)
				{			
					$dt = strtotime( $_POST['going']);
					$day = date("D", $dt);
					$a=strtoupper($day);?>
		

                        <div class="container mgtop70">
                            <table class="table">
                                <thead>
                                  <tr>
                                    <th>Agency name</th>
                                    <th>Bus name</th>
                                    <th>Day of journey</th>
                                    <th>Bus number</th>
                                    <th>Window seat</th>
                                    <th>Other  seat</th>
                                    <th>Ticket</th>
                                    <th>Departure time</th>
                                    <th>Reaching time</th>
                                </tr>
                              </thead>
							<?php 	
								if(($_POST['droping_point']!="0")&&($_POST['boarding_city']!="0")&&($_POST['going']!=null))
											{
											$query="select * from cities where city_name='".$_POST['boarding_city']."'";  
											if(fetch($query))
												{
												foreach(fetch($query) as $city_boarding)
												{
													foreach(fetch("select * from cities where city_name='".$_POST['droping_point']."'") as $city_droping)
														{
																
												$query1="select * from timming where Day='".$a."'";
													
												if(fetch($query1))
												{
												foreach(fetch($query1)as $going)
													{
														$query_fetch1 ="select * from routes where id=".$going['route_id']." and boarding_point_id=".$city_boarding['city_id']."																																												                                                                    and dropping_point_id=".$city_droping['city_id']."";
														
																		if(fetch($query_fetch1))
																			{
																				foreach(fetch($query_fetch1)as $going1)
																					{	foreach(fetch("select * from bus where id=".$going1['bus_id']." order by ticket")as                                                                                        $goingbus)
																			               {	?>		
													 
																					<tbody>			
                                                                					<tr>
																						 <?php
                                                                                          foreach(fetch("select * from agency where id=".$goingbus['agency_id']."")as $agency )
                                                                                                {  ?><td><?php echo  $agency['name'] ?></td><?php
                                                                                                }?>	
																								<td><?php echo 	$goingbus['name'] ?></td>
                                                                                                    <td><?php echo $a ?></td>
                                                                                                    <td><?php echo 	$goingbus['bus_number'] ?></td>
                                                                                                    <td><?php echo  $goingbus['window_seat'] ?></td>
                                                                                                    <td><?php echo 	$goingbus['other_seat'] ?></td>
                                                                                                    <td><?php echo 	$goingbus['ticket'] ?></td>
                                                                                                    <td><?php echo   $going['from_bus_time'] ?></td>
                                                                                                    <td><?php echo   $going['bus_to_time'] ?></td>
																					<form action="search.php?go=1" method="post">
																					       <input type="hidden" value="<?php echo $_POST['going'] ?>" name="date_of_journey" />
                                                                                           <input type="hidden" value="<?php echo $going1['bus_id'] ?>" name="bus_id" />
                                                                                           <input type="hidden" value="<?php echo $agency['name'] ?>" name="agency_name" />
                                                                                           <input type="hidden" value="<?php echo $goingbus['name'] ?>" name="bus_name" />
                                                                                           <input type="hidden" value="<?php echo $goingbus['window_seat'] ?>" name="window1" />
                                                                                           <input type="hidden" value="<?php echo $goingbus['bus_number'] ?>" name="bus_number" />
                                                                                           <input type="hidden" value="<?php echo $going['from_bus_time'] ?>" name="bus_time" />
                                                                                           <input type="hidden" value="<?php echo $going['bus_to_time'] ?>" name="bus_time1" />
                                                                                           <input type="hidden" value="<?php echo $goingbus['other_seat'] ?>" name="other1" /> 
                                                                                           <input type="hidden" value="<?php echo $goingbus['ticket'] ?>" name="ticket1" />
                                                                                           <input type="hidden" value="<?php echo $going['route_id'] ?>" name="route" />
                                                                                            <td><button>go</button></td>
																					</form>
                                                                                    
							<?php							
																}
																								
																					}
																			}
																		else
																				{?>
																				<table>
																					<thead>
																			       <tr><center><p style="font-size:40px;">oops!sorry no bus found for this route</p></center><tr>	
																					<thead>
																				</table>
																		  <?php 
																		  		exit();
																			}	
																					
																}
															}
															else
																{?>
																<table>
																	<thead>
																		<tr><center><p style="font-size:40px;">oops!sorry no bus found for this route</p></center><tr>	
																	<thead>
																</table>
														  <?php }	
														}
											
								     	
												
										
										}
										
					       	  
							
							      }else
								  		{
											?><table>
																	<thead>
																		<tr><center><p style="font-size:40px;">No such type of boarding point exist</p></center><tr>	
																	<thead>
																</table><?php 
										}
								  }
								  
							
							}
							
			     }
  }
?>
<?php 
if(isset($_GET["go"]))
{ 
	if($_POST['date_of_journey']!=null)
		{	$d=$_POST['date_of_journey'];
			$i=$_POST['bus_id'];
			$t=$_POST['bus_time'];
		    $w=$_POST['window1'];
			$o=$_POST['other1'];
			?>
			<div class="container">
			<?php 
				?>
               
               <?php 
			   $query_fetch ="SELECT * FROM `order_table` WHERE date_of_journey='$d' and bus_id='$i' and from_bus_time='$t'";
		if(fetch($query_fetch))
		{
							
						foreach(fetch($query_fetch)as $booked)
					{			
						   $window_seat[] = $booked['window_seat_no'];
			        		$other_seat[]=$booked['other_seat_no'];
					}
								 $a=implode($window_seat);
										$str = $a;
										$e=(explode(" ",$str));
										array_unshift($e, "phoney");
										unset($e[0]);?>
										<h2>Window seats</h2><?php
										for($l=1;$l<=$w;$l++)
											  {?>
														<?php if(array_search($l,$e))
																{?>
                                                                	 <input type="checkbox" disabled="disabled" />
                                                                		
															<?php }	
															 else
																{?>
																			<input type="checkbox" id=" <?php echo $l ?>"   onchange="handler.call(this)" />
                                                          <?php }
											}
										?>
						<h4>Window seats no</h4><p id="demo"></p>
                       					  
									<h3>other seats</h3><?php
										$b=implode($other_seat);
									 	$stro = $b;
										$f=(explode(" ",$stro));
										array_unshift($f, "phoney");
										unset($f[0]);
										for($lo=1;$lo<=$o;$lo++)
										  {?>
													<?php if(array_search($lo,$f))
															{?> 
                                                             <input type="checkbox"  disabled="disabled" />
													  <?php }	
														 else
															{?>
                                                      		<input type="checkbox" id=" <?php echo $lo ?>"    onchange="otherhandler.call(this)" />
														<?php }
										}?><h4>Other seat number </h4><p id="demo1"></p><?php
										
				}				
								
                         else
						 {
						 		?><h2>window seats</h2><?php	    
									for($el=1;$el<=$w;$el++)
										{
											?><input type="checkbox" id=" <?php echo $el ?>"  onchange="handler.call(this)" /><?php
										}
							   ?><h4>window seats</h4><p id="demo"></p><?php
							 
						 	   		?><h2>other seats</h2><?php
									for($elo=1;$elo<=$w;$elo++)
										{
											?><input type="checkbox" id=" <?php echo $elo ?>"    onchange="otherhandler.call(this)" /><?php
										}
										?><h4>Other seat number </h4><p id="demo1"></p><?php
							} 
							  
                  				?>
				  	
                    	<form action="coupen.php?detail=1" method="post">
                        	<input type="hidden" name="agency_name" value="<?php echo $_POST['agency_name'] ?>"/>
                            <input type="hidden" name="bus_name" value="<?php echo $_POST['bus_name'] ?>"/>
                            <input type="hidden" name="bus_number" value="<?php echo $_POST['bus_number'] ?>"/>
                            <input type="hidden" name="from_bus_time" value="<?php echo $_POST['bus_time'] ?>"/>
                            <input type="hidden" name="bus_to_time" value="<?php echo $_POST['bus_time1'] ?>"/>
                            <input type="hidden" id="seat_no" name="seats_selected" />
                            <input type="hidden" id="number_of_seat" name="number_seats"  />
                            <input type="hidden" id="seat_no1" name="seats_selected1" />
                            <input type="hidden" id="number_of_seat1" name="number_seats1"  />
                            <input type="hidden" value="<?php echo $_POST['ticket1'] ?>" name="ticket" />
                            <input type="hidden" value="<?php echo $_POST['bus_id'] ?>" name="bus_id" />
                            <input type="hidden" name="date_of_journey" value="<?php echo $_POST['date_of_journey'] ?>" />
                            <input type="hidden" value="<?php echo $_POST['route'] ?>" name="route" />
            			     <center><button class="btn btn-primary" style="margin-bottom:20px;width:100px;">Book now</button></center>
						</form>
                 </div>       
	<?php		}
	
}
    
?> 

</body>
</html>
