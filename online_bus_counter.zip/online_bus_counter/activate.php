<?php
        if(isset($_SESSION['username']))
	{
		redirect_to("dashboard.php");
	}	

	include("inc/database.php");
	start_session();	
	database_connection();
 
	if(isset($_GET['id']))
	{
		$query = "UPDATE users SET activate = 1 WHERE email='{$_GET['id']}'";
		execute($query);
		$_SESSION['activate'] = 1;
		redirect_to("index.php");
	
	}
 
 ?>